---
name: place-shorts
description: 플에이스영어 9:16 세로 숏폼(인스타 릴스·유튜브 쇼츠)을 만든다. 대본·자막 → 내 녹음(또는 11랩스 내 목소리) → Remotion 렌더 → 프레임 검수. "쇼츠 만들어줘", "릴스 만들어줘", "세로 영상" 요청에 사용한다.
---

# 플에이스 쇼츠 (place-shorts)

9:16 세로 숏폼을 코드로 만든다. 브랜드(빨강·파랑·노랑 3색 밴드, Paperlogy, 로고)는 템플릿에 들어 있다. 기계음 TTS는 쓰지 않는다 — **원장님 녹음 또는 11랩스 내 목소리**만 쓴다.

## 핵심 원칙
- **음성은 하나의 연속 트랙**: 문장별로 쪼개 붙이지 않는다. 녹음할 때 줄 사이를 0.5초 이상 쉬면 스크립트가 쉬는 구간으로 장면 경계를 자동으로 잡는다.
- **화면은 음성에 싱크**: `src/timings.json`의 경계대로 장면이 바뀐다.
- **검수는 눈으로**: `npx remotion still`로 프레임을 뽑아 직접 읽고 `references/checklist.md`로 판정한다.

## 준비 (최초 1회)
```bash
cp -r <이 스킬>/template <작업폴더>/shorts-<주제>   # 경로에 공백·한글 없이
cd <작업폴더>/shorts-<주제> && npm install
```
Node.js 18+ 필요. 11랩스를 쓸 때만 `.env`(`.env.example` 복사)가 필요하다.

## 파이프라인
1. **기획** — 주제·대상·길이(20~35초)·첫 3초 훅 한 줄. 비어 있으면 내가 정해서 알린다.
2. **대본/자막** — `narration.json`(말할 문장 배열)과 `src/shorts.ts`(화면 장면)를 쓴다. 장면 수 = 나레이션 줄 수. 규칙은 `references/brand.md`, 서브에이전트를 쓸 때는 `references/subagents.md`.
3. **음성** — 사용자에게 선택을 물어본다: (A) 내 녹음: 대본을 읽어 `recordings/<id>.m4a`로 저장 → `npm run voice:rec` / (B) 11랩스: `.env` 설정 → `npm run voice:eleven`. 결과는 `public/audio/<id>.mp3` + `src/timings.json`.
4. **효과음** — `npm run sfx`.
5. **렌더** — `npm run render:all` → `out/*.mp4`. 새 편은 `Root.tsx`에 Composition 한 줄, `package.json`에 render 스크립트 한 줄 추가.
6. **검수** — 장면마다 `npx remotion still <CompId> out/chk-N.png --frame=F` → 이미지를 열어 자막 넘침·폰트(Paperlogy 로드 여부)·강조·싱크·안전영역 확인. 실패하면 2~5로 돌아간다.

자세한 단계는 `references/pipeline.md`.

## 반드시 지킬 것
- 색·폰트·로고는 바꾸지 않는다(`src/theme.ts`, `src/fonts.ts`). 다른 학원 로고·사진 금지.
- "1등", "합격 보장", "100%", 가짜 후기, 근거 없는 수치 금지. 신청 안내는 "프로필 링크의 상담 신청서".
- 아이·학부모 얼굴과 이름은 동의받은 경우에만. 아니면 블러하거나 쓰지 않는다.
- 컴퓨터가 느려 렌더가 멈추면 `remotion.config.ts`의 `setConcurrency(2)`를 1로 낮춘다.

## 화질을 높여 달라고 할 때
원장님이 "화질을 더 선명하게"라고 하면 렌더할 때 화질 값(`--crf`)을 낮춰서 다시 렌더합니다. 기본은 16~18이고, 12~14로 낮추면 더 선명하지만 파일이 커집니다. 원본 영상 자체가 흐리면 렌더만으로는 선명해지지 않으니, 원본이 흐린지 먼저 확인해서 알려 줍니다. 인스타그램에 올릴 때 한 번 더 압축되는 것은 막을 수 없다고 안내합니다.
