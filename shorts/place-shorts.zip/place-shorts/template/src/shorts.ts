import { BgKind, C, FPS } from "./theme";

export type Token = { t: string; hl?: boolean; color?: string };
export type Chip = { t: string; kind: "blue" | "red" };
export type SceneData = {
  bg: BgKind;
  eyebrow?: string;
  title: Token[];       // 큰 캡션 (강조 토큰 hl)
  sub?: string;
  chips?: Chip[];
  cta?: string;
  defaultDur: number;   // 오디오 없을 때 기본 길이(프레임)
  sfx?: "whoosh" | "pop" | "ding";
};
export type ShortData = { id: string; scenes: SceneData[] };

const s = (n: number) => Math.round(n * FPS);

// 샘플 2편 — 내용은 매번 새로 쓴다(구조와 모션만 재사용). 근거 없는 수치·보장 문구 금지.
// bg: "cream"(밝은 배경) | "navy"(진한 배경) | "blue"(브랜드 블루)
// title 토큰: { t, hl:true } = 형광펜/노랑 강조, { t, color } = 지정색

// ── 1) 밝은 톤 — 학부모 정보형
export const TIPS: ShortData = {
  id: "tips",
  scenes: [
    { bg: "cream", eyebrow: "초등 영어 · 학부모 Q&A", sfx: "pop", defaultDur: s(4),
      title: [{ t: "영어, 단어부터\n" }, { t: "외우게", hl: true }, { t: " 하시나요?" }],
      sub: "순서를 바꾸면 아이가 편해져요" },
    { bg: "cream", eyebrow: "먼저 이것부터", sfx: "whoosh", defaultDur: s(5),
      title: [{ t: "소리 " }, { t: "→ ", color: C.red }, { t: "문장\n" }, { t: "→ 글자", hl: true }],
      chips: [{ t: "듣기", kind: "blue" }, { t: "말하기", kind: "blue" }, { t: "읽기·쓰기", kind: "red" }] },
    { bg: "blue", eyebrow: "플에이스영어", sfx: "ding", defaultDur: s(5),
      title: [{ t: "아이 속도에 맞춘\n" }, { t: "레벨 상담", color: C.yellow }],
      sub: "상담은 프로필 링크에서 신청해요" },
    { bg: "navy", eyebrow: "상담 신청", sfx: "ding", defaultDur: s(4),
      title: [{ t: "프로필 링크의\n" }, { t: "상담 신청서", color: C.yellow }],
      cta: "▶ 지금 신청하세요" },
  ],
};

// ── 2) 진한 톤 — 개념 정리형
export const CONCEPT: ShortData = {
  id: "concept",
  scenes: [
    { bg: "navy", eyebrow: "문장 구조 · 개념정리", sfx: "pop", defaultDur: s(4),
      title: [{ t: "주어 ", color: C.blue }, { t: "+ " }, { t: "동사", color: C.red }],
      sub: "문장의 뼈대는 이 두 개" },
    { bg: "navy", eyebrow: "목적어 · 보어", sfx: "whoosh", defaultDur: s(5),
      title: [{ t: "뒤에 오는 말은\n" }, { t: "노란색", color: C.yellow }],
      sub: "목적어와 보어를 한 색으로 묶어요" },
    { bg: "navy", eyebrow: "정리", sfx: "ding", defaultDur: s(5),
      title: [{ t: "주어 ", color: C.blue }, { t: "동사 ", color: C.red }, { t: "목적어·보어", color: C.yellow }],
      cta: "▶ 프로필 링크에서 상담 신청" },
  ],
};

export const SHORTS: Record<string, ShortData> = { TipsShort: TIPS, ConceptShort: CONCEPT };
