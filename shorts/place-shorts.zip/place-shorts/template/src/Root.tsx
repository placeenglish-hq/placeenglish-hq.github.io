import React from "react";
import { Composition } from "remotion";
import { Short, ShortProps, Timing } from "./Short";
import { TIPS, CONCEPT, ShortData } from "./shorts";
import { FPS, H, W } from "./theme";
import TIMINGS from "./timings.json";

// src/timings.json = { tips:{total, cuts:[...]}, concept:{...} }  (npm run voice:* 가 채움)
const makeCalc = (short: ShortData) => () => {
  const info = (TIMINGS as Record<string, { total: number; cuts: number[]; ext?: string }>)[short.id];
  if (info && Array.isArray(info.cuts) && info.cuts.length === short.scenes.length) {
    let prev = 0;
    const timings: Timing[] = info.cuts.map((c) => {
      const t = { start: Math.round(prev * FPS), dur: Math.max(1, Math.round((c - prev) * FPS)) };
      prev = c;
      return t;
    });
    return {
      durationInFrames: Math.max(1, Math.round(info.total * FPS)),
      fps: FPS, width: W, height: H,
      props: { short, timings, audioReady: true, sfxEnabled: true, ext: info.ext ?? "mp3" } as ShortProps,
    };
  }
  // 폴백: 오디오 없을 때 기본 길이 · 무음
  let start = 0;
  const timings: Timing[] = short.scenes.map((s) => {
    const t = { start, dur: s.defaultDur };
    start += s.defaultDur;
    return t;
  });
  return { durationInFrames: start, fps: FPS, width: W, height: H, props: { short, timings, audioReady: false, sfxEnabled: false } as ShortProps };
};

const dflt = (short: ShortData): ShortProps => ({ short, timings: [], audioReady: false, sfxEnabled: false });

export const RemotionRoot: React.FC = () => (
  <>
    <Composition id="TipsShort" component={Short} durationInFrames={540} fps={FPS} width={W} height={H} defaultProps={dflt(TIPS)} calculateMetadata={makeCalc(TIPS)} />
    <Composition id="ConceptShort" component={Short} durationInFrames={570} fps={FPS} width={W} height={H} defaultProps={dflt(CONCEPT)} calculateMetadata={makeCalc(CONCEPT)} />
  </>
);
