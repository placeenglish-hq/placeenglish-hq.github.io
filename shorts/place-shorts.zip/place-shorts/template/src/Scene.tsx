import React from "react";
import { AbsoluteFill, Img, interpolate, spring, staticFile } from "remotion";
import "./fonts";
import { DISPLAY } from "./fonts";
import { BG, C, FPS, subColor, textColor } from "./theme";
import { SceneData } from "./shorts";
import { Burst, GlowPulse, Shine } from "./motion";

const rev = (frame: number, delay: number, dur = 18) =>
  spring({ frame: frame - delay, fps: FPS, config: { damping: 200 }, durationInFrames: dur });

export const Scene: React.FC<{ data: SceneData; frame: number; dur: number }> = ({ data, frame }) => {
  const base = textColor[data.bg];
  const accent = data.bg === "cream" ? C.red : C.yellow;
  const float = Math.sin(frame / 22) * 4;

  // 배경 드리프트 blob
  const blobX = Math.sin(frame / 40) * 40;
  const blobY = Math.cos(frame / 34) * 30;

  // 타이틀 토큰별 스태거 등장
  const nodes: React.ReactNode[] = [];
  let ti = 0;
  data.title.forEach((tk, i) => {
    tk.t.split("\n").forEach((seg, j) => {
      if (j > 0) nodes.push(<br key={`br-${i}-${j}`} />);
      if (seg === "") return;
      const delay = 6 + ti * 3; ti++;
      const r = rev(frame, delay);
      const special = Boolean(tk.hl || tk.color);
      const y = (1 - r) * 46;
      const sc = special ? 0.62 + 0.38 * r : 1;
      let style: React.CSSProperties = {
        display: "inline-block", whiteSpace: "pre", opacity: r, transform: `translateY(${y}px) scale(${sc})`,
        color: tk.color ?? base, transformOrigin: "left bottom",
      };
      if (tk.hl) {
        style = data.bg === "cream"
          ? { ...style, color: C.ink, background: `linear-gradient(transparent 56%, ${C.yellowHl} 56%)`, padding: "0 6px" }
          : { ...style, color: C.yellow };
      }
      nodes.push(<span key={`t-${i}-${j}`} style={style}>{seg}</span>);
    });
  });

  const eb = rev(frame, 0);
  const lineGrow = rev(frame, 3);
  const subR = rev(frame, 6 + ti * 3 + 4);
  const ctaR = rev(frame, 6 + ti * 3 + 8);

  return (
    <AbsoluteFill style={{ background: BG[data.bg], fontFamily: DISPLAY, overflow: "hidden" }}>
      {/* 드리프트 blob */}
      <div style={{ position: "absolute", width: 720, height: 720, borderRadius: "50%", top: 480 + blobY, left: 380 + blobX,
        background: `radial-gradient(circle, ${data.bg === "navy" ? "rgba(42,138,210,.22)" : data.bg === "blue" ? "rgba(255,255,255,.12)" : "rgba(42,138,210,.10)"}, transparent 68%)`, filter: "blur(6px)" }} />

      {/* 타이틀 뒤 글로우 펄스 (다크/그린) */}
      {data.bg !== "cream" && <div style={{ position: "absolute", left: "40%", top: "52%" }}><GlowPulse color={accent} size={580} /></div>}

      {/* 로고 */}
      <div style={{ position: "absolute", top: 86, left: 72, display: "flex", alignItems: "center", gap: 16, opacity: eb }}>
        <Img src={staticFile("img/logo.png")} style={{ width: 62, height: 62, objectFit: "contain" }} />
        <div style={{ fontWeight: 900, fontSize: 34, color: base }}>플에이스영어</div>
      </div>

      {/* 본문 */}
      <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", justifyContent: "center", padding: "0 84px", transform: `translateY(${float}px)` }}>
        {data.eyebrow && (
          <div style={{ display: "flex", alignItems: "center", gap: 18, marginBottom: 26, opacity: eb, transform: `translateX(${(1 - eb) * -30}px)` }}>
            <div style={{ width: 46 * lineGrow, height: 6, borderRadius: 3, background: accent }} />
            <div style={{ fontSize: 40, fontWeight: 800, color: accent, letterSpacing: ".02em" }}>{data.eyebrow}</div>
          </div>
        )}
        <div style={{ fontSize: 128, fontWeight: 900, lineHeight: 1.08, letterSpacing: "-.02em", color: base }}>{nodes}</div>
        {data.sub && (
          <div style={{ marginTop: 34, fontSize: 50, fontWeight: 700, color: subColor[data.bg], opacity: subR, transform: `translateY(${(1 - subR) * 24}px)` }}>{data.sub}</div>
        )}
        {data.chips && (
          <div style={{ marginTop: 40, display: "flex", gap: 18, flexWrap: "wrap" }}>
            {data.chips.map((c, i) => {
              const cr = rev(frame, 6 + ti * 3 + 6 + i * 3);
              const st: React.CSSProperties = data.bg === "cream"
                ? { background: c.kind === "blue" ? C.blueWash : C.redWash, color: c.kind === "blue" ? C.blue : C.red, border: `2px solid ${c.kind === "blue" ? "#BBD9F0" : "#F6C5BF"}` }
                : { background: "rgba(255,255,255,.1)", color: "#eaf5f0", border: "2px solid rgba(255,255,255,.2)" };
              return <div key={i} style={{ ...st, fontSize: 40, fontWeight: 900, padding: "16px 28px", borderRadius: 16, opacity: cr, transform: `scale(${0.7 + 0.3 * cr})` }}>{c.t}</div>;
            })}
          </div>
        )}
        {data.cta && (
          <div style={{ marginTop: 54, alignSelf: "flex-start", opacity: ctaR, transform: `translateY(${(1 - ctaR) * 24}px) scale(${0.9 + 0.1 * ctaR})`,
            background: data.bg === "cream" ? C.red : C.yellow, color: data.bg === "cream" ? "#fff" : C.ink, fontSize: 48, fontWeight: 900, padding: "30px 44px", borderRadius: 22 }}><Shine start={Math.round(1.1 * FPS)} dur={30}>{data.cta}</Shine></div>
        )}
      </div>

      {/* CTA 순간 파티클 버스트 */}
      {data.cta && <Burst at={Math.round(0.9 * FPS)} color={accent} cx={0.42} cy={0.55} count={22} />}
    </AbsoluteFill>
  );
};
