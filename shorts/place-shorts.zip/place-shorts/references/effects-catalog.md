# 효과 카탈로그 (쇼츠용)

이 스킬의 `src/motion.tsx`에 들어 있는 모션 블록만 정리했습니다. 색은 `src/theme.ts` 토큰(빨강·파랑·노랑)만 쓰세요.

---

# 1. 모션 블록 — `src/motion.tsx`

순수 Remotion, **의존성 0**, 결정적(`random(seed)`). React 18/19 공용. 쇼츠·롱폼 공용.

> HeyGen HyperFrames 계열(HTML→헤드리스 크롬→FFmpeg)을 Remotion 네이티브로 구현한 것.
> Lottie/GSAP가 꼭 필요하면 `@remotion/lottie`·`gsap`(프레임 동기화)로 추가할 수 있으나,
> 아래 블록으로 대부분의 연출이 커버된다.

| 블록 | 용도 | 주요 props |
|---|---|---|
| `AuroraBg` | shader-feel 오로라 배경(움직이는 컬러 블롭) | `colors[]`, `base`, `speed`, `blur` |
| `Grain` | 필름 그레인 질감 오버레이 | `opacity`(0.04~0.08) |
| `Shine` | 텍스트/버튼 위 빛 스윕(광택) | `start`, `dur`, `color` (children 감쌈) |
| `Kinetic` | 키네틱 타이포(글자별 등장) | `text`, `delay`, `stagger`, `style` |
| `Burst` | 파티클 버스트(강조/CTA 순간) | `at`, `count`, `color`, `spread`, `cx/cy` |
| `GlowPulse` | 요소 뒤 은은한 빛 맥동(깊이감) | `color`, `size` (부모 position 필요) |
| `ClipWipe` | 클립 와이프 등장 전환 | `start`, `dur`, `dir` |

```tsx
import { AuroraBg, Grain, Shine, Burst, GlowPulse, Kinetic } from "./motion";

<AuroraBg colors={["#0FA588","#2ED4C6","#123056"]} />
<div style={{position:"absolute",left:"40%",top:"52%"}}><GlowPulse color="#2ED4C6" size={560}/></div>
<Shine start={33} dur={30}>{cta}</Shine>
<Burst at={27} color="#2ED4C6" cx={0.42} cy={0.55} />
<Kinetic text="자동 완성" delay={6} stagger={2} style={{fontSize:120,fontWeight:900}}/>
<Grain opacity={0.05} />
```

**현재 통합**
- 쇼츠 `Short.tsx`: 전역 `Grain(0.05)` · `Scene.tsx`: 다크/그린 씬 타이틀 뒤 `GlowPulse`, CTA에 `Shine`+`Burst`
- 롱폼 `LongformVideo.tsx`: 전역 `Grain(0.045)`. 나머지는 씬별로.

---


---

# 절제 원칙

화려함은 **한 곳(시그니처)에만.** 그레인은 은은하게(≤0.06), 버스트·샤인은 강조 순간에만.
정보 전달 톤에서는 **절제가 곧 품질**이다. 한 씬에 SFX는 1~2개.
