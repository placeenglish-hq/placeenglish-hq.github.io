---
name: place-longform
description: 플에이스영어 가로 롱폼(유튜브·학부모 설명 영상, 1920×1080)을 만든다. 대본 → 내 녹음(또는 11랩스 내 목소리) → Remotion 렌더. "롱폼 만들어줘", "유튜브 영상", "학부모 설명 영상" 요청에 사용한다. 세로 숏폼은 place-shorts.
---

# 플에이스 롱폼 (place-longform)

정보 전달형 가로 영상을 대본부터 mp4까지 만든다. 크림 배경 + 상단 3색 밴드 + 라인 아이콘 + 상단 중앙 캡션 + 왼쪽 챕터 표시. 색·폰트(Paperlogy)·로고는 템플릿에 들어 있다. 기계음 TTS는 쓰지 않고 **원장님 녹음 또는 11랩스 내 목소리**만 쓴다.

## 흐름
`주제 → 1.기획 → 2.대본(scenes.json) → 3.음성 → 4.미리보기 → 5.렌더 → 6.검수`

## 준비 (최초 1회)
```bash
cp -r <이 스킬>/template <작업폴더>/longform-<주제>   # 경로에 공백·한글 없이
cd <작업폴더>/longform-<주제> && npm install
```
Node.js 18+ 필요. 11랩스를 쓸 때만 `.env`(`.env.example` 복사) 필요.

## 1. 기획
훅(첫 10~15초) → 오프닝 → 본문 3~6개(개념 하나씩) → 요약 → 상담 안내. 아웃라인을 먼저 보여주고 승인받은 뒤 대본을 쓴다. 분량 기준은 분당 320~360자.

## 2. 대본
`src/scenes.json`에 씬별로 쓴다(스키마는 파일의 샘플 참고). `narration`(말할 문장), `icon`(Lucide 아이콘 이름 — 없는 이름은 `src/components/Icon.tsx`의 MAP에 추가), `keyword`(굵게 강조할 단어), `section`(왼쪽 챕터). 규칙은 `references/script-guide.md`. `durationSec`, `cues`, `meta.audioFile`은 직접 쓰지 않는다 — 음성 단계가 채운다.

## 3. 음성 — 사용자에게 선택을 물어본다
- **A. 내 녹음(무료)**: 대본 전체를 씬 순서대로 한 번에 읽어 `recordings/voice.m4a`로 저장. **씬이 바뀔 때 1초쯤 쉰다.** → `npm run voice:rec`
- **B. 11랩스**: `.env`에 `ELEVEN_API_KEY`, `ELEVEN_VOICE_ID` → `npm run voice:eleven` (글자 단위 타이밍이라 자막 싱크가 가장 정확)

둘 다 `public/audio/voice.mp3`와 scenes.json(씬 길이·자막·오디오 경로)을 채운다. 대본을 고치면 다시 실행한다.

## 4. 효과음 · 미리보기
```bash
npm run sfx     # 효과음 생성 (whoosh·pop·ding·riser 등)
npm run dev     # 브라우저 미리보기
```

## 5. 렌더
```bash
npm run render  # → out/video.mp4 (1920×1080, 30fps)
```
컴퓨터가 느리면 `remotion.config.ts`의 `setConcurrency(2)`를 1로 낮춘다.

## 6. 검수 (반드시 눈으로)
`npx remotion still Longform out/chk-N.png --frame=F`로 씬마다 한 장씩 뽑아 열어 본다: 캡션이 넘치지 않는지, 아이콘이 동그라미(미등록)로 나오지 않는지, 폰트가 Paperlogy인지, 자막이 음성과 맞는지.

## 반드시 지킬 것
- 색·폰트·로고는 바꾸지 않는다(`src/components/theme.ts`, `src/fonts.ts`).
- "1등", "합격 보장", "100%", 가짜 후기, 근거 없는 수치 금지. 신청 안내는 "프로필 링크의 상담 신청서".
- 아이·학부모 얼굴과 이름은 동의받은 경우에만.
- API 키는 `.env`에만 두고 공유·업로드하지 않는다.

## 화질을 높여 달라고 할 때
원장님이 "화질을 더 선명하게"라고 하면 렌더할 때 화질 값(`--crf`)을 낮춰서 다시 렌더합니다. 기본은 16~18이고, 12~14로 낮추면 더 선명하지만 파일이 커집니다. 원본 영상 자체가 흐리면 렌더만으로는 선명해지지 않으니, 원본이 흐린지 먼저 확인해서 알려 줍니다. 인스타그램에 올릴 때 한 번 더 압축되는 것은 막을 수 없다고 안내합니다.
