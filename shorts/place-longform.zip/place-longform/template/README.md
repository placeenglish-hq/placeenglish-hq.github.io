# 플에이스영어 롱폼 (Remotion)

1. `npm install`
2. `src/scenes.json`에 대본 작성 (샘플이 들어 있어요)
3. 목소리: 내 녹음 → `recordings/voice.m4a` 저장 후 `npm run voice:rec` / 11랩스 → `.env` 설정 후 `npm run voice:eleven`
4. `npm run sfx` → `npm run dev`(미리보기) → `npm run render` (결과 `out/video.mp4`)

씬이 바뀔 때 1초 쉬며 녹음하면 씬 경계가 자동으로 잡힙니다. 자세한 규칙은 상위 폴더의 SKILL.md와 references/ 를 보세요.
