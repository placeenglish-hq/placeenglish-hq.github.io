// ElevenLabs(11랩스) → 롱폼 음성 + 씬 길이 + 글자 단위 정확 자막
// 준비: .env 에 ELEVEN_API_KEY, ELEVEN_VOICE_ID   (선택 ELEVEN_MODEL)
// 실행: npm run voice:eleven
import { writeFileSync, mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { loadScenes, saveScenes, splitCaption, ROOT } from "./lib.mjs";

const KEY = process.env.ELEVEN_API_KEY, VOICE = process.env.ELEVEN_VOICE_ID;
const MODEL = process.env.ELEVEN_MODEL || "eleven_multilingual_v2";
if (!KEY || !VOICE) { console.error("✗ .env 에 ELEVEN_API_KEY, ELEVEN_VOICE_ID 를 넣어 주세요"); process.exit(1); }
mkdirSync(new URL("public/audio/", ROOT), { recursive: true });

const data = loadScenes();
const scenes = data.scenes;
const texts = scenes.map((s) => (s.narration || "").trim());
const full = texts.join(" ");
// 5000자 제한 회피: 길면 씬 묶음 단위로 나눠 호출하고 이어붙인다 → 단순화를 위해 한 번에 호출(≈ 10분 이내 권장)
if (full.length > 9000) console.warn("⚠ 대본이 길어요. 11랩스 글자 제한에 걸리면 영상을 2편으로 나누세요.");

const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${VOICE}/with-timestamps?output_format=mp3_44100_128`, {
  method: "POST", headers: { "xi-api-key": KEY, "Content-Type": "application/json" },
  body: JSON.stringify({ text: full, model_id: MODEL, voice_settings: { stability: 0.5, similarity_boost: 0.8, style: 0.15 } }),
});
if (!res.ok) { console.error(`✗ ${res.status} ${(await res.text()).slice(0, 300)}`); process.exit(1); }
const j = await res.json();
writeFileSync(fileURLToPath(new URL("public/audio/voice.mp3", ROOT)), Buffer.from(j.audio_base64, "base64"));
const a = j.alignment || j.normalized_alignment;
const st = a.character_start_times_seconds, en = a.character_end_times_seconds;
const total = en[en.length - 1];

let pos = 0; const starts = [];
texts.forEach((t) => { starts.push(st[Math.min(pos, st.length - 1)]); pos += t.length + 1; });
pos = 0;
scenes.forEach((s, i) => {
  const t = texts[i]; const begin = i === 0 ? 0 : Math.max(0, starts[i] - 0.1);
  const end = i + 1 < scenes.length ? Math.max(0, starts[i + 1] - 0.1) : total + 0.5;
  s.durationSec = +(end - begin).toFixed(3);
  // 자막: 줄마다 해당 글자의 실제 시작/끝 시각
  let p = pos; const cues = [];
  for (const line of splitCaption(t)) {
    const at = t.indexOf(line, p - pos); const from = st[Math.min(pos + at, st.length - 1)];
    const to = en[Math.min(pos + at + line.length - 1, en.length - 1)];
    cues.push({ text: line, from: +Math.max(0, from - begin).toFixed(3), to: +(to - begin + 0.15).toFixed(3) });
    p = pos + at + line.length;
  }
  if (cues.length) cues[cues.length - 1].to = +(s.durationSec - 0.05).toFixed(3);
  s.cues = cues;
  pos += t.length + 1;
});
data.meta.audioFile = "audio/voice.mp3";
saveScenes(data);
console.log(`✓ ${total.toFixed(1)}초 · 씬 ${scenes.length}개 · 자막 글자 단위 싱크`);
