// 내 녹음 → 롱폼 음성 + 씬 길이 + 자막
// 사용: 대본 전체를 씬 순서대로 한 번에 녹음. 씬이 바뀔 때마다 1초 정도 쉬세요(문장 사이는 짧게).
//       recordings/voice.m4a 로 저장 → npm run voice:rec
// 하는 일: 긴 쉬는 구간 (씬 수-1)개를 씬 경계로 잡아 scenes.json 의 durationSec/cues/meta.audioFile 을 채운다.
import { readdirSync, mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { ffmpeg, probeDuration, loadScenes, saveScenes, proportionalCues, ROOT } from "./lib.mjs";

const recDir = new URL("recordings/", ROOT);
mkdirSync(recDir, { recursive: true });
mkdirSync(new URL("public/audio/", ROOT), { recursive: true });
const src = readdirSync(recDir).find((f) => /^voice\.(m4a|wav|mp3|aac|mp4|mov|ogg)$/i.test(f));
if (!src) { console.error("✗ recordings/voice.m4a 가 없어요. 대본을 읽어 녹음해서 이 이름으로 넣어 주세요."); process.exit(1); }

const out = fileURLToPath(new URL("public/audio/voice.mp3", ROOT));
const enc = ffmpeg(["-y", "-i", fileURLToPath(new URL(src, recDir)), "-vn", "-af", "loudnorm=I=-16:TP=-1.5:LRA=11", "-ar", "48000", "-ac", "1", "-b:a", "160k", out]);
if (enc.status !== 0) { console.error("✗ 변환 실패\n" + enc.stderr?.slice(-400)); process.exit(1); }
const total = probeDuration(out);

const data = loadScenes();
const scenes = data.scenes;
const need = scenes.length - 1;
let gaps = [];
for (const [db, d] of [[-35, 0.8], [-33, 0.6], [-30, 0.5], [-28, 0.4], [-25, 0.3]]) {
  const r = ffmpeg(["-i", out, "-af", `silencedetect=noise=${db}dB:d=${d}`, "-f", "null", "-"]);
  const t = r.stderr || "";
  const st = [...t.matchAll(/silence_start:\s*([\d.]+)/g)].map((m) => +m[1]);
  const en = [...t.matchAll(/silence_end:\s*([\d.]+)/g)].map((m) => +m[1]);
  gaps = st.map((s, i) => ({ s, e: en[i] ?? total })).filter((g) => g.s > 0.5 && g.e < total - 0.1);
  if (gaps.length >= need) break;
}
let bounds;
if (gaps.length >= need) {
  bounds = [...gaps].sort((a, b) => (b.e - b.s) - (a.e - a.s)).slice(0, need).sort((a, b) => a.s - b.s).map((g) => (g.s + g.e) / 2);
  console.log(`✓ 쉬는 구간으로 씬 ${scenes.length}개 분할`);
} else {
  const ch = scenes.map((s) => (s.narration || "").replace(/\s/g, "").length);
  const sum = ch.reduce((a, b) => a + b, 0); let acc = 0;
  bounds = ch.slice(0, -1).map((c) => (acc += c) / sum * total);
  console.warn(`⚠ 쉬는 구간이 ${gaps.length}개뿐(필요 ${need}) → 글자 수 비례로 나눴어요. 씬 사이를 더 길게 쉬고 다시 녹음하면 정확해집니다.`);
}
const starts = [0, ...bounds];
scenes.forEach((s, i) => {
  const end = i + 1 < scenes.length ? starts[i + 1] : total + 0.5;
  s.durationSec = +(end - starts[i]).toFixed(3);
  s.cues = proportionalCues(s.narration || "", s.durationSec - 0.2);
});
data.meta.audioFile = "audio/voice.mp3";
saveScenes(data);
console.log(`✓ 총 ${total.toFixed(1)}초 · scenes.json 갱신 (자막 시간은 글자 수 비례 — 어긋나면 씬을 더 잘게 나누세요)`);
