// 공용 유틸 — ffmpeg 실행 / timings.json 병합
import { spawnSync } from "node:child_process";
import { readFileSync, writeFileSync, existsSync } from "node:fs";

export const ROOT = new URL("../", import.meta.url);

// ffmpeg: 시스템 ffmpeg 우선, 없으면 remotion 내장 (npx remotion ffmpeg)
export const ffmpeg = (args, opts = {}) => {
  let r = spawnSync("ffmpeg", args, { encoding: "utf8", maxBuffer: 1 << 28, ...opts });
  if (r.error) r = spawnSync("npx", ["remotion", "ffmpeg", ...args], { encoding: "utf8", maxBuffer: 1 << 28, shell: process.platform === "win32", ...opts });
  return r;
};

export const probeDuration = (file) => {
  const r = ffmpeg(["-i", file]);
  const m = /Duration:\s*(\d+):(\d+):([\d.]+)/.exec((r.stderr || "") + (r.stdout || ""));
  if (!m) throw new Error("길이를 읽지 못했어요: " + file);
  return +m[1] * 3600 + +m[2] * 60 + +m[3];
};

export const loadNarration = () => JSON.parse(readFileSync(new URL("narration.json", ROOT), "utf8"));

export const saveTiming = (id, info) => {
  const f = new URL("src/timings.json", ROOT);
  const all = existsSync(f) ? JSON.parse(readFileSync(f, "utf8")) : {};
  all[id] = info;
  writeFileSync(f, JSON.stringify(all, null, 2));
};

// ── 롱폼 전용 ──
export const SCENES = new URL("src/scenes.json", ROOT);
export const loadScenes = () => JSON.parse(readFileSync(SCENES, "utf8"));
export const saveScenes = (d) => writeFileSync(SCENES, JSON.stringify(d, null, 2));

// 내레이션 → 자막 줄 (문장 끝 + 최대 길이 기준)
export const splitCaption = (text, max = 24) => {
  const sents = text.match(/[^.!?。]+[.!?。]?/g)?.map((s) => s.trim()).filter(Boolean) ?? [text];
  const out = [];
  for (const s of sents) {
    if (s.length <= max) { out.push(s); continue; }
    const words = s.split(/\s+/); let cur = "";
    for (const w of words) {
      if ((cur + " " + w).trim().length > max && cur) { out.push(cur.trim()); cur = w; } else cur = (cur + " " + w).trim();
    }
    if (cur) out.push(cur.trim());
  }
  return out;
};

// 글자 수 비례로 자막 시간을 배분 (dur = 씬 길이 초)
export const proportionalCues = (text, dur) => {
  const parts = splitCaption(text);
  const w = parts.map((p) => Math.max(1, p.replace(/\s/g, "").length));
  const sum = w.reduce((a, b) => a + b, 0);
  let t = 0;
  return parts.map((p, i) => {
    const from = t; t += (w[i] / sum) * dur;
    return { text: p, from: +from.toFixed(3), to: +(i === parts.length - 1 ? dur : t).toFixed(3) };
  });
};
