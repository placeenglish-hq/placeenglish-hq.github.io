// 효과음 — Node로 직접 합성 (무료·오프라인·의존성 0). whoosh / pop / ding → public/sfx/*.wav
// 실행: npm run sfx
import { writeFileSync, mkdirSync } from "node:fs";

const SR = 44100;
const dir = new URL("../public/sfx/", import.meta.url);
mkdirSync(dir, { recursive: true });

const toWav = (samples) => {
  const n = samples.length;
  const buf = Buffer.alloc(44 + n * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + n * 2, 4); buf.write("WAVE", 8);
  buf.write("fmt ", 12); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write("data", 36); buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) {
    let s = Math.max(-1, Math.min(1, samples[i]));
    buf.writeInt16LE((s * 32767) | 0, 44 + i * 2);
  }
  return buf;
};
const gen = (dur, fn) => { const n = (dur * SR) | 0; const a = new Float32Array(n); for (let i = 0; i < n; i++) a[i] = fn(i / SR, i / n); return a; };

// whoosh — 엔벨로프 씌운 노이즈 + 하이패스 느낌(차분)
const whoosh = gen(0.7, (t, p) => {
  const env = Math.sin(Math.PI * p) ** 1.5;
  const n = (Math.random() * 2 - 1);
  const tone = Math.sin(2 * Math.PI * (200 + 900 * p) * t) * 0.15; // 상승감
  return (n * 0.6 + tone) * env * 0.5;
});
// pop — 짧은 사인 블립 + 빠른 감쇠
const pop = gen(0.14, (t) => {
  const env = Math.exp(-t * 42);
  return Math.sin(2 * Math.PI * (520 - 180 * t * 6) * t) * env * 0.6;
});
// ding — 화음 사인 + 지수 감쇠
const ding = gen(0.6, (t) => {
  const env = Math.exp(-t * 5.5);
  const s = Math.sin(2 * Math.PI * 880 * t) + 0.6 * Math.sin(2 * Math.PI * 1320 * t) + 0.35 * Math.sin(2 * Math.PI * 1760 * t);
  return s * env * 0.22;
});


// ── 롱폼에서 쓰는 추가 소리
const transition = gen(0.35, (t, p) => Math.sin(Math.PI * p) ** 1.5 * (Math.random() * 2 - 1) * 0.3);
const click = gen(0.05, (t) => Math.sin(2 * Math.PI * 1800 * t) * Math.exp(-t * 90) * 0.5);
const impact = gen(0.9, (t) => Math.sin(2 * Math.PI * (70 - 30 * t) * t) * Math.exp(-t * 5) * 0.8);
const riser = gen(1.6, (t, p) => (Math.sin(2 * Math.PI * (200 + 1400 * p * p) * t) * 0.25 + (Math.random() * 2 - 1) * 0.12 * p) * p ** 1.3 * 0.7);

for (const [name, data] of Object.entries({ whoosh, pop, ding, transition, click, impact, riser })) {
  writeFileSync(new URL(`../public/sfx/${name}.wav`, import.meta.url), toWav(data));
  console.log(`✓ ${name}.wav`);
}
console.log("\n효과음 생성 완료 → public/sfx  (sfxEnabled 는 기본 켜짐)");
