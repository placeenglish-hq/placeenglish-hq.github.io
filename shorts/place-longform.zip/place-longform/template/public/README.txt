이 폴더는 Remotion 정적 자산(static assets) 폴더입니다.

- audio/       : tts.mjs 가 생성한 내레이션 mp3가 여기에 저장됩니다.
- music/bg.mp3 : (선택) 배경음악. 넣은 뒤 src/scenes.json 의 meta.music 을 "music/bg.mp3" 로 지정하면 자동으로 낮게 깔립니다.
- images/      : (선택) 화면에 넣을 이미지가 있으면 여기에.

코드에서는 staticFile("audio/scene-01.mp3") 처럼 이 폴더 기준 상대경로로 참조합니다.
