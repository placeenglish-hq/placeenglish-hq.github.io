import React from "react";
import { Composition } from "remotion";
import { LongformVideo } from "./LongformVideo";
import scenesData from "./scenes.json";

const FPS = 30;
const WIDTH = 1920;
const HEIGHT = 1080;

// TTS 전에는 durationSec가 없을 수 있으니 대본 길이로 대략 추정(한국어 ≈ 5.5자/초).
export function estimateSec(scene: { narration?: string; durationSec?: number }) {
  if (typeof scene.durationSec === "number" && scene.durationSec > 0) return scene.durationSec;
  const n = (scene.narration || "").replace(/\s/g, "").length;
  return Math.max(2.5, n / 5.5 + 0.4);
}

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="Longform"
      component={LongformVideo as React.FC<Record<string, unknown>>}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
      defaultProps={{ data: scenesData }}
      calculateMetadata={({ props }) => {
        const data = (props as { data: typeof scenesData }).data;
        const frames = data.scenes.reduce(
          (acc, s) => acc + Math.ceil(estimateSec(s) * FPS),
          0
        );
        return { durationInFrames: Math.max(frames, FPS), fps: FPS };
      }}
    />
  );
};
