import React from "react";
import { Sequence, Audio, staticFile, useVideoConfig } from "remotion";
import { SfxCue } from "./effects";

// 씬 안에서 SFX 큐를 시간에 맞춰 재생. 각 씬 Sequence 내부에 두면 씬 시작 기준으로 배치된다.
export const Sfx: React.FC<{ cues?: SfxCue[]; durationInFrames: number }> = ({ cues, durationInFrames }) => {
  const { fps } = useVideoConfig();
  if (!cues || cues.length === 0) return null;
  return (
    <>
      {cues.map((c, i) => {
        let startFrame = 0;
        if (c.at === "in") startFrame = 0;
        else if (c.at === "out") startFrame = Math.max(0, durationInFrames - Math.round(0.5 * fps));
        else startFrame = Math.round((c.delay ?? 0) * fps);
        startFrame = Math.min(startFrame, Math.max(0, durationInFrames - 1));
        return (
          <Sequence key={i} from={startFrame} name={`sfx-${c.sound}`}>
            <Audio src={staticFile(`sfx/${c.sound}.wav`)} volume={c.volume ?? 0.5} />
          </Sequence>
        );
      })}
    </>
  );
};
