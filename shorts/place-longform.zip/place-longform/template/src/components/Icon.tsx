import React from "react";
import {
  Bell, Phone, Smartphone, Search, Briefcase, Palette, FileText, Gamepad2,
  TrendingUp, Coins, DollarSign, BookOpen, Video, Mail, Users, Lightbulb,
  Target, Rocket, Check, CheckCircle2, Star, BarChart3, MessageSquare, Bot,
  Sparkles, Play, Globe, MapPin, ThumbsUp, Megaphone, GraduationCap, Pencil,
  Eye, Trophy, Clock, Zap, Newspaper, ShieldCheck, Handshake, Circle,
  Ear, MessageCircle, Mic, Headphones, Book, BookMarked, Pen, Smile, Heart, Home, School, Calendar, Baby, Puzzle, Layers, Languages, Volume2, Flag,
} from "lucide-react";

// scenes.json 의 icon 문자열(케밥/파스칼) → Lucide 컴포넌트.
const MAP: Record<string, React.ComponentType<{ size?: number; strokeWidth?: number; color?: string }>> = {
  bell: Bell, phone: Phone, smartphone: Smartphone, search: Search,
  briefcase: Briefcase, palette: Palette, "file-text": FileText, "gamepad-2": Gamepad2,
  "trending-up": TrendingUp, coins: Coins, "dollar-sign": DollarSign, "book-open": BookOpen,
  video: Video, mail: Mail, users: Users, lightbulb: Lightbulb, target: Target,
  rocket: Rocket, check: Check, "check-circle": CheckCircle2, star: Star,
  "bar-chart": BarChart3, "message-square": MessageSquare, bot: Bot, sparkles: Sparkles,
  play: Play, globe: Globe, "map-pin": MapPin, "thumbs-up": ThumbsUp, megaphone: Megaphone,
  "graduation-cap": GraduationCap, pencil: Pencil, eye: Eye, trophy: Trophy, clock: Clock,
  ear: Ear, "message-circle": MessageCircle, mic: Mic, headphones: Headphones, book: Book,
  "book-marked": BookMarked, pen: Pen, smile: Smile, heart: Heart, home: Home, school: School,
  calendar: Calendar, baby: Baby, puzzle: Puzzle, layers: Layers, languages: Languages,
  "volume-2": Volume2, flag: Flag,
  zap: Zap, newspaper: Newspaper, "shield-check": ShieldCheck, handshake: Handshake,
};

export const resolveIcon = (name?: string) => {
  if (name && !MAP[name]) console.warn(`[Icon] "${name}" 은 등록되지 않았어요 → src/components/Icon.tsx 의 MAP 에 추가하세요`);
  return (name && MAP[name]) || Circle;
};

// 라인아이콘 렌더 헬퍼(색/굵기 기본값 = 참고 영상의 얇은 흑백 라인)
export const LineIcon: React.FC<{ name?: string; size?: number; strokeWidth?: number; color?: string }> = ({
  name,
  size = 360,
  strokeWidth = 1.5,
  color = "#181822",
}) => {
  const Cmp = resolveIcon(name);
  return <Cmp size={size} strokeWidth={strokeWidth} color={color} />;
};
