// 롱폼 — 효과 상수/헬퍼. 씬 겹침(TransitionSeries) 대신 씬별 enter/exit로
// 구현해 씬 길이를 정확히 유지 → 연속 내레이션과 싱크가 안 어긋난다.

export const ENTER_FRAMES = 16; // 등장 애니메이션 길이(프레임)
export const EXIT_FRAMES = 14;  // 퇴장(줌아웃 페이드) 길이(프레임)

export type TransitionKind = "fade" | "slideUp" | "slideLeft" | "zoom" | "none";
export type EffectKind = "kenburns" | "none";

export type SfxCue = {
  // "in" = 씬 시작, "out" = 씬 끝 근처, "point" = delay(초) 지점
  at: "in" | "out" | "point";
  sound: "click" | "pop" | "ding" | "whoosh" | "transition" | "riser" | "impact";
  delay?: number; // at:"point" 일 때 씬 시작 기준 초
  volume?: number;
};

export const easeOutCubic = (x: number) => 1 - Math.pow(1 - x, 3);
export const easeInCubic = (x: number) => x * x * x;
