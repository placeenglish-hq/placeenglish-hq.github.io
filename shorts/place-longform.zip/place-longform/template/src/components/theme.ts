// 롱폼 — 플에이스영어 디자인 토큰. 색·폰트는 여기서만 바꾼다.
export const theme = {
  bg: "#FAF7F0",        // 크림
  bgSoft: "#F1ECDF",
  fg: "#181822",        // 잉크
  fgMuted: "#6B6B7B",
  accent: "#2A8AD2",    // 브랜드 블루
  accent2: "#EA5242",   // 브랜드 레드
  yellow: "#FFCC28",
  captionBg: "rgba(24,24,34,0.88)",
  captionFg: "#FFFFFF",

  font: "'Paperlogy','Malgun Gothic','Apple SD Gothic Neo',sans-serif",
  titleSize: 84,
  sectionTitleSize: 72,
  bulletSize: 40,
  captionSize: 54,
  introTitleSize: 96,

  padX: 140,
  radius: 24,

  introSec: 3.2,
  outroSec: 3.5,
  fadeSec: 0.5,
} as const;

export type Theme = typeof theme;
