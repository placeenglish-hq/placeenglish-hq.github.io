import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate, spring } from "remotion";
import { theme } from "./theme";
import { Captions } from "./Captions";
import type { Cue } from "../LongformVideo";

// 아웃트로: 중앙 정리 문구 + CTA.
export const Outro: React.FC<{ title: string; cta?: string; cues?: Cue[] }> = ({ title, cta, cues }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({ frame, fps, config: { damping: 200 } });
  const opacity = interpolate(s, [0, 1], [0, 1]);
  const y = interpolate(s, [0, 1], [30, 0]);
  const ctaIn = interpolate(frame, [16, 34], [0, 1], { extrapolateRight: "clamp", extrapolateLeft: "clamp" });

  return (
    <AbsoluteFill
      style={{
        background: `radial-gradient(1200px 700px at 50% 55%, ${theme.bgSoft}, ${theme.bg})`,
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <div style={{ textAlign: "center", padding: `0 ${theme.padX}px`, transform: `translateY(${y}px)`, opacity }}>
        <div style={{ fontSize: theme.titleSize, fontWeight: 900, color: theme.fg, letterSpacing: "-0.03em", lineHeight: 1.12 }}>
          {title}
        </div>
        {cta && (
          <div
            style={{
              marginTop: 44,
              display: "inline-block",
              fontSize: 36,
              fontWeight: 700,
              color: theme.bg,
              background: theme.accent,
              padding: "20px 40px",
              borderRadius: 999,
              opacity: ctaIn,
            }}
          >
            {cta}
          </div>
        )}
      </div>

      <Captions cues={cues} />
    </AbsoluteFill>
  );
};
