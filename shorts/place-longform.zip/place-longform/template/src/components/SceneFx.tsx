import React from "react";
import { AbsoluteFill, useCurrentFrame, interpolate } from "remotion";
import { ENTER_FRAMES, EXIT_FRAMES, TransitionKind, easeOutCubic, easeInCubic } from "./effects";

// 씬 콘텐츠(중앙 히어로)를 감싸 등장·퇴장 모션을 준다.
// 등장 = 줌인(0.9→1)+페이드, 퇴장 = 줌아웃(1→1.14)+페이드 → 씬 전환이 줌 모핑처럼 이어진다.
// 씬 길이를 소모하지 않으므로 연속 내레이션 오디오와 싱크가 유지된다.
export const SceneFx: React.FC<{
  transition?: TransitionKind;
  durationInFrames: number;
  children: React.ReactNode;
}> = ({ transition = "fade", durationInFrames, children }) => {
  const frame = useCurrentFrame();

  const enterRaw = interpolate(frame, [0, ENTER_FRAMES], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const enter = easeOutCubic(enterRaw);
  const exitStart = durationInFrames - EXIT_FRAMES;
  const exitRaw = interpolate(frame, [exitStart, durationInFrames], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const exit = easeInCubic(exitRaw);

  const opacity = Math.min(enter, 1 - exit);

  // 줌: 등장 0.9→1, 퇴장 1→1.14
  const enterScale = interpolate(enter, [0, 1], [0.9, 1]);
  const exitScale = interpolate(exit, [0, 1], [1, 1.14]);
  let scale = enterScale * exitScale;

  let tx = 0;
  let ty = 0;
  if (transition === "slideUp") ty = interpolate(enter, [0, 1], [80, 0]);
  else if (transition === "slideLeft") tx = interpolate(enter, [0, 1], [110, 0]);
  else if (transition === "zoom") scale = enterScale * exitScale * interpolate(enter, [0, 1], [1.04, 1]);

  return (
    <AbsoluteFill style={{ opacity, transform: `translate(${tx}px, ${ty}px) scale(${scale})`, transformOrigin: "center 56%" }}>
      {children}
    </AbsoluteFill>
  );
};
