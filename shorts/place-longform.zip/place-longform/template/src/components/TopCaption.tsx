import React from "react";
import { useCurrentFrame, useVideoConfig, interpolate } from "remotion";
import { theme } from "./theme";
import type { Cue } from "../LongformVideo";

// 상단 중앙 한 줄 캡션. 키워드만 볼드 검정 + 밑줄이 스윕되며 그어지고, 살짝 팝.
export const TopCaption: React.FC<{ cues?: Cue[]; keyword?: string }> = ({ cues, keyword }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  if (!cues || cues.length === 0) return null;
  const t = frame / fps;
  const idx = cues.findIndex((c) => t >= c.from && t < c.to);
  const active = idx >= 0 ? cues[idx] : t >= cues[cues.length - 1].to ? null : cues[0];
  if (!active) return null;

  const local = t - active.from; // 이 캡션이 뜬 뒤 경과(초)
  const inT = interpolate(local, [0, 0.18], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const y = interpolate(inT, [0, 1], [12, 0]);
  const kwPop = interpolate(local, [0, 0.16], [1.18, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const uw = interpolate(local, [0.06, 0.34], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });

  const text = active.text;
  const parts: { s: string; hot: boolean }[] = [];
  if (keyword && text.includes(keyword)) {
    const i = text.indexOf(keyword);
    if (i > 0) parts.push({ s: text.slice(0, i), hot: false });
    parts.push({ s: keyword, hot: true });
    if (i + keyword.length < text.length) parts.push({ s: text.slice(i + keyword.length), hot: false });
  } else {
    parts.push({ s: text, hot: false });
  }
  const hasHot = parts.some((p) => p.hot);

  return (
    <div
      style={{
        position: "absolute",
        top: 130,
        left: 0,
        right: 0,
        display: "flex",
        justifyContent: "center",
        padding: `0 ${theme.padX}px`,
        opacity: inT,
        transform: `translateY(${y}px)`,
        zIndex: 40,
      }}
    >
      <div style={{ maxWidth: "80%", textAlign: "center", fontSize: theme.captionSize, lineHeight: 1.35, letterSpacing: "-0.01em" }}>
        {parts.map((p, i) =>
          p.hot ? (
            <span
              key={i}
              style={{
                position: "relative",
                display: "inline-block",
                fontWeight: 800,
                color: theme.fg,
                transform: `scale(${kwPop})`,
                transformOrigin: "center bottom",
                paddingBottom: 6,
              }}
            >
              {p.s}
              <span
                style={{
                  position: "absolute",
                  left: 0,
                  bottom: 0,
                  height: 4,
                  width: `${uw * 100}%`,
                  background: theme.fg,
                  borderRadius: 2,
                }}
              />
            </span>
          ) : (
            <span key={i} style={{ fontWeight: hasHot ? 500 : 700, color: hasHot ? theme.fgMuted : theme.fg }}>
              {p.s}
            </span>
          )
        )}
      </div>
    </div>
  );
};
