import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate, spring } from "remotion";
import { theme } from "./theme";
import { Captions } from "./Captions";
import type { Cue } from "../LongformVideo";

// 오프닝: 중앙 대형 타이틀 + 부제. 부드러운 등장.
export const Intro: React.FC<{ title: string; subtitle?: string; cues?: Cue[] }> = ({ title, subtitle, cues }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({ frame, fps, config: { damping: 200 } });
  const opacity = interpolate(s, [0, 1], [0, 1]);
  const scale = interpolate(s, [0, 1], [0.96, 1]);
  const subIn = interpolate(frame, [10, 26], [0, 1], { extrapolateRight: "clamp", extrapolateLeft: "clamp" });

  return (
    <AbsoluteFill
      style={{
        background: `radial-gradient(1200px 700px at 50% 40%, ${theme.bgSoft}, ${theme.bg})`,
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <div style={{ textAlign: "center", padding: `0 ${theme.padX}px`, transform: `scale(${scale})`, opacity }}>
        <div
          style={{
            display: "inline-block",
            fontSize: 30,
            fontWeight: 700,
            color: theme.accent,
            letterSpacing: "0.08em",
            textTransform: "uppercase",
            marginBottom: 28,
            opacity: subIn,
          }}
        >
          {subtitle}
        </div>
        <div
          style={{
            fontSize: theme.introTitleSize,
            fontWeight: 900,
            color: theme.fg,
            letterSpacing: "-0.03em",
            lineHeight: 1.1,
          }}
        >
          {title}
        </div>
        <div style={{ margin: "40px auto 0", width: 120, height: 6, borderRadius: 3, background: theme.accent, opacity: subIn }} />
      </div>

      <Captions cues={cues} />
    </AbsoluteFill>
  );
};
