import React from "react";
import { useCurrentFrame, useVideoConfig, spring, interpolate } from "remotion";
import { resolveIcon } from "./Icon";
import { theme } from "./theme";

// 좌측 세로 챕터 인덱스: 원형 라인아이콘들을 선으로 연결, 현재 챕터는 검정 채움 + 등장 시 팝.
export const ChapterRail: React.FC<{ chapters?: string[]; active?: number }> = ({ chapters, active = 0 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  if (!chapters || chapters.length < 2) return null;
  const size = 62;
  const gap = 26;

  const pop = spring({ frame, fps, config: { damping: 180 }, durationInFrames: 16 });
  const activeScale = interpolate(pop, [0, 1], [0.72, 1]);
  // 연결선이 현재 챕터까지 채워지는 진행 표시
  const railFill = interpolate(pop, [0, 1], [0, 1]);

  return (
    <div
      style={{
        position: "absolute",
        left: 70,
        top: "50%",
        transform: "translateY(-50%)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap,
        zIndex: 30,
      }}
    >
      <div style={{ position: "absolute", top: size / 2, bottom: size / 2, width: 2, background: "#DDD6C6" }} />
      {chapters.map((name, i) => {
        const on = i === active;
        const done = i < active;
        const Cmp = resolveIcon(name);
        return (
          <div
            key={i}
            style={{
              width: size,
              height: size,
              borderRadius: "50%",
              border: `2px solid ${theme.fg}`,
              background: on || done ? theme.fg : "#FFFFFF",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              zIndex: 1,
              transform: on ? `scale(${activeScale})` : "scale(1)",
              opacity: on ? interpolate(railFill, [0, 1], [0.4, 1]) : 1,
              boxShadow: on ? "0 6px 18px rgba(0,0,0,0.18)" : "none",
            }}
          >
            <Cmp size={26} strokeWidth={2} color={on || done ? "#FFFFFF" : theme.fg} />
          </div>
        );
      })}
    </div>
  );
};
