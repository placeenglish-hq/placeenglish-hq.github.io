import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate } from "remotion";
import { theme } from "./theme";
import { LineIcon } from "./Icon";
import type { SceneData } from "../LongformVideo";

// 참고 영상 스타일 본체: 흰 배경 + 중앙 라인아트 히어로.
// 모션: (1) 라인이 그려지듯 등장(stroke draw-in), (2) 켄번즈 슬로우 줌인, (3) 은은한 부유.
// 상단 캡션·좌측 챕터레일은 LongformVideo에서 얹는다.
export const Scene: React.FC<{ scene: SceneData; kind?: string }> = ({ scene, kind }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();

  // 켄번즈: 씬 내내 아주 천천히 확대(정적이지 않게)
  const kb = interpolate(frame, [0, Math.max(durationInFrames, 1)], [1.0, 1.06]);
  const floatY = Math.sin(frame / 26) * 4;

  // 스트로크 드로잉: 라인이 그려지듯 등장 (dasharray는 아이콘 경로 길이대(24 viewBox)에 맞춰 300)
  const drawFrac = interpolate(frame, [3, 40], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const dashOffset = (drawFrac * 300).toFixed(1);
  const cls = `hero-${scene.id}`;
  const drawCss = `.${cls} svg path, .${cls} svg line, .${cls} svg circle, .${cls} svg rect, .${cls} svg polyline, .${cls} svg polygon { stroke-dasharray: 300; stroke-dashoffset: ${dashOffset}; stroke-linecap: round; stroke-linejoin: round; }`;

  const size = kind === "intro" ? 300 : 360;

  return (
    <AbsoluteFill style={{ backgroundColor: theme.bg, alignItems: "center", justifyContent: "center" }}>
      <style>{drawCss}</style>
      <div className={cls} style={{ transform: `translateY(${64 + floatY}px) scale(${kb})` }}>
        <LineIcon name={scene.icon} size={size} strokeWidth={1.6} />
      </div>
    </AbsoluteFill>
  );
};
