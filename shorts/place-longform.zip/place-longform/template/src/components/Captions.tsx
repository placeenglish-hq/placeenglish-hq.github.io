import React from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "./theme";
import type { Cue } from "../LongformVideo";

// 하단 자막. cues의 from/to(초, 씬 시작 기준)에 맞춰 현재 줄을 표시.
export const Captions: React.FC<{ cues?: Cue[] }> = ({ cues }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  if (!cues || cues.length === 0) return null;
  const t = frame / fps;
  const active = cues.find((c) => t >= c.from && t < c.to) ?? (t >= cues[cues.length - 1].to ? null : cues[0]);
  if (!active) return null;

  return (
    <div
      style={{
        position: "absolute",
        left: 0,
        right: 0,
        bottom: 96,
        display: "flex",
        justifyContent: "center",
        padding: `0 ${theme.padX}px`,
        zIndex: 40,
      }}
    >
      <div
        style={{
          background: theme.captionBg,
          color: theme.captionFg,
          fontSize: theme.captionSize,
          fontWeight: 600,
          lineHeight: 1.35,
          padding: "18px 34px",
          borderRadius: 16,
          maxWidth: "80%",
          textAlign: "center",
          letterSpacing: "-0.01em",
          boxShadow: "0 8px 40px rgba(0,0,0,0.35)",
        }}
      >
        {active.text}
      </div>
    </div>
  );
};
