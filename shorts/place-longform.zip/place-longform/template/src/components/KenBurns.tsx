import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate } from "remotion";
import { theme } from "./theme";

// 이미지가 없어도 배경에 은은한 움직임을 준다(켄번즈 느낌).
// 라디얼 그라디언트 패널을 아주 천천히 확대/이동시켜 화면이 '숨쉬게' 한다.
export const KenBurns: React.FC<{ enabled?: boolean; seed?: number }> = ({ enabled = true, seed = 0 }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  if (!enabled) {
    return <AbsoluteFill style={{ backgroundColor: theme.bg }} />;
  }
  const p = durationInFrames > 1 ? frame / (durationInFrames - 1) : 0;
  const dir = seed % 2 === 0 ? 1 : -1;
  const scale = interpolate(p, [0, 1], [1.06, 1.14]);
  const tx = interpolate(p, [0, 1], [0, 26 * dir]);
  const ty = interpolate(p, [0, 1], [0, -18]);
  const gx = 50 + (seed % 3) * 8;

  return (
    <AbsoluteFill style={{ backgroundColor: theme.bg, overflow: "hidden" }}>
      <AbsoluteFill
        style={{
          transform: `scale(${scale}) translate(${tx}px, ${ty}px)`,
          background: `radial-gradient(1100px 720px at ${gx}% 38%, ${theme.bgSoft}, ${theme.bg} 70%)`,
        }}
      />
    </AbsoluteFill>
  );
};
