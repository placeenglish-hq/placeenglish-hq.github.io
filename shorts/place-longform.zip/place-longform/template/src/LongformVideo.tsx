import React from "react";
import { AbsoluteFill, Img, Sequence, Audio, staticFile, useVideoConfig, useCurrentFrame, interpolate } from "remotion";
import { theme } from "./components/theme";
import { Scene } from "./components/Scene";
import { SceneFx } from "./components/SceneFx";
import { Sfx } from "./components/Sfx";
import { TopCaption } from "./components/TopCaption";
import { ChapterRail } from "./components/ChapterRail";
import { TransitionKind, SfxCue } from "./components/effects";
import { estimateSec } from "./Root";

export type Cue = { text: string; from: number; to: number };
export type SceneData = {
  id: string;
  kind?: "intro" | "section" | "outro";
  narration?: string;
  durationSec?: number;
  cues?: Cue[];
  // 참고 영상 스타일
  icon?: string;         // 중앙 라인아트(Lucide 아이콘 이름, 케밥/파스칼)
  keyword?: string;      // 캡션에서 볼드+밑줄 강조할 단어
  section?: number;      // 좌측 챕터레일에서 현재 챕터 인덱스
  transition?: TransitionKind;
  sfx?: SfxCue[];
  // (구버전 호환) title/bullets/effect 는 더 이상 렌더하지 않음
  title?: string;
  bullets?: string[];
};
export type ShowData = {
  meta: {
    title: string;
    subtitle?: string;
    cta?: string;
    audioFile?: string;
    music?: string;
    musicVolume?: number;
    chapters?: string[]; // 좌측 챕터레일 아이콘들(Lucide 이름)
  };
  scenes: SceneData[];
};

const GlobalProgress: React.FC = () => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const pct = interpolate(frame, [0, durationInFrames - 1], [0, 100], { extrapolateRight: "clamp" });
  return (
    <div style={{ position: "absolute", bottom: 0, left: 0, height: 5, width: `${pct}%`, background: theme.accent, zIndex: 50 }} />
  );
};

const TopKicker: React.FC<{ text: string }> = ({ text }) => (
  <div style={{ position: "absolute", top: 66, left: 0, right: 0, textAlign: "center", zIndex: 40 }}>
    <span style={{ fontSize: 28, fontWeight: 700, letterSpacing: "0.14em", color: theme.accent, textTransform: "uppercase" }}>{text}</span>
  </div>
);

const CtaPill: React.FC<{ text: string }> = ({ text }) => (
  <div style={{ position: "absolute", bottom: 120, left: 0, right: 0, display: "flex", justifyContent: "center", zIndex: 40 }}>
    <div style={{ background: theme.fg, color: "#fff", fontSize: 34, fontWeight: 700, padding: "18px 40px", borderRadius: 999 }}>{text}</div>
  </div>
);

export const LongformVideo: React.FC<{ data: ShowData }> = ({ data }) => {
  const { fps } = useVideoConfig();
  let cursor = 0;

  return (
    <AbsoluteFill style={{ backgroundColor: theme.bg, fontFamily: theme.font }}>
      {data.meta.audioFile && <Audio src={staticFile(data.meta.audioFile)} />}
      {data.meta.music && <Audio src={staticFile(data.meta.music)} volume={data.meta.musicVolume ?? 0.06} loop />}

      {data.scenes.map((scene) => {
        const durFrames = Math.ceil(estimateSec(scene) * fps);
        const from = cursor;
        cursor += durFrames;
        const kind = scene.kind ?? "section";
        const transition: TransitionKind = scene.transition ?? (kind === "intro" ? "zoom" : "fade");
        return (
          <Sequence key={scene.id} from={from} durationInFrames={durFrames} name={`scene-${scene.id}`}>
            <Sfx cues={scene.sfx} durationInFrames={durFrames} />
            {kind === "section" && <ChapterRail chapters={data.meta.chapters} active={scene.section ?? 0} />}
            <SceneFx transition={transition} durationInFrames={durFrames}>
              <Scene scene={scene} kind={kind} />
            </SceneFx>
            <TopCaption cues={scene.cues} keyword={scene.keyword} />
            {kind === "intro" && data.meta.subtitle && <TopKicker text={data.meta.subtitle} />}
            {kind === "outro" && data.meta.cta && <CtaPill text={data.meta.cta} />}
          </Sequence>
        );
      })}

      {/* 상단 3색 밴드 + 로고 */}
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 12, display: "flex", zIndex: 60 }}>
        <div style={{ flex: 1, background: "#EA5242" }} /><div style={{ flex: 1, background: "#2A8AD2" }} /><div style={{ flex: 1, background: "#FFCC28" }} />
      </div>
      <div style={{ position: "absolute", top: 34, right: 56, display: "flex", alignItems: "center", gap: 12, zIndex: 60 }}>
        <Img src={staticFile("img/logo.png")} style={{ width: 44, height: 44, objectFit: "contain" }} />
        <span style={{ fontSize: 26, fontWeight: 900, color: theme.fg }}>플에이스영어</span>
      </div>
      <GlobalProgress />
    </AbsoluteFill>
  );
};
