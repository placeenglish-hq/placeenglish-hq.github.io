import { continueRender, delayRender, staticFile } from "remotion";

// 브랜드 폰트 Paperlogy (7Bold / 8ExtraBold / 9Black) — public/fonts 에 포함됨
const handle = delayRender("load-fonts");

const load = async () => {
  const faces = [
    new FontFace("Paperlogy", `url(${staticFile("fonts/Paperlogy-7Bold.woff2")}) format('woff2')`, { weight: "700" }),
    new FontFace("Paperlogy", `url(${staticFile("fonts/Paperlogy-8ExtraBold.woff2")}) format('woff2')`, { weight: "800" }),
    new FontFace("Paperlogy", `url(${staticFile("fonts/Paperlogy-9Black.woff2")}) format('woff2')`, { weight: "900" }),
  ];
  try {
    await Promise.all(faces.map((f) => f.load()));
    faces.forEach((f) => (document as any).fonts.add(f));
  } catch (e) {
    // 폰트 실패해도 렌더는 진행 (fallback: Malgun Gothic) — 결과 확인 시 폰트가 바뀌었는지 꼭 볼 것
    console.warn("Paperlogy 로드 실패", e);
  }
  continueRender(handle);
};

load();


