// 모션 블록 라이브러리 (하이퍼프레임식) — 순수 Remotion, 의존성 0, 결정적(random 시드 사용).
// AuroraBg · Grain · Shine · Kinetic · Burst · GlowPulse · ClipWipe. React 18/19 공용.
import React from "react";
import { AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig } from "remotion";

const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);

/** shader-feel 오로라 배경 — 움직이는 컬러 블롭 */
export const AuroraBg: React.FC<{ colors?: string[]; base?: string; speed?: number; blur?: number }> = ({
  colors = ["#0FA588", "#2ED4C6", "#123056"], base = "#0b1a34", speed = 1, blur = 70,
}) => {
  const f = useCurrentFrame();
  const { width, height } = useVideoConfig();
  return (
    <AbsoluteFill style={{ background: base, overflow: "hidden" }}>
      {colors.map((c, i) => {
        const t = (f * speed) / 60 + i * 2.1;
        const x = width * (0.3 + 0.4 * Math.sin(t * 0.7 + i));
        const y = height * (0.3 + 0.4 * Math.cos(t * 0.5 + i * 1.3));
        const s = Math.min(width, height) * (0.7 + 0.18 * Math.sin(t + i));
        return <div key={i} style={{ position: "absolute", left: x - s / 2, top: y - s / 2, width: s, height: s, borderRadius: "50%", background: `radial-gradient(circle, ${c}AA, transparent 70%)`, filter: `blur(${blur}px)`, mixBlendMode: "screen" }} />;
      })}
    </AbsoluteFill>
  );
};

/** 필름 그레인 오버레이 */
export const Grain: React.FC<{ opacity?: number }> = ({ opacity = 0.06 }) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ opacity, mixBlendMode: "overlay", pointerEvents: "none" }}>
      <svg width="100%" height="100%">
        <filter id={`grain${f % 4}`}><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed={f % 12} /></filter>
        <rect width="100%" height="100%" filter={`url(#grain${f % 4})`} />
      </svg>
    </AbsoluteFill>
  );
};

/** 빛 스윕 (텍스트/요소 위를 지나가는 광택) */
export const Shine: React.FC<{ children: React.ReactNode; start?: number; dur?: number; color?: string }> = ({
  children, start = 0, dur = 26, color = "rgba(255,255,255,.75)",
}) => {
  const f = useCurrentFrame();
  const p = interpolate(f, [start, start + dur], [-30, 130], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <span style={{ position: "relative", display: "inline-block" }}>
      {children}
      <span style={{ position: "absolute", inset: 0, background: `linear-gradient(105deg, transparent ${p - 16}%, ${color} ${p}%, transparent ${p + 16}%)`, mixBlendMode: "screen", pointerEvents: "none" }} />
    </span>
  );
};

/** 키네틱 타이포 — 글자별 등장 */
export const Kinetic: React.FC<{ text: string; delay?: number; stagger?: number; style?: React.CSSProperties }> = ({
  text, delay = 0, stagger = 2, style,
}) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <span style={style}>
      {[...text].map((ch, i) => {
        const s = spring({ frame: f - delay - i * stagger, fps, config: { damping: 200 }, durationInFrames: 16 });
        return <span key={i} style={{ display: "inline-block", whiteSpace: "pre", opacity: s, transform: `translateY(${(1 - s) * 34}px) rotate(${(1 - s) * -7}deg)` }}>{ch}</span>;
      })}
    </span>
  );
};

/** 파티클 버스트 (강조/CTA 순간) */
export const Burst: React.FC<{ at?: number; count?: number; color?: string; spread?: number; cx?: number; cy?: number }> = ({
  at = 0, count = 20, color = "#2ED4C6", spread = 340, cx = 0.5, cy = 0.5,
}) => {
  const f = useCurrentFrame();
  const { fps, width, height } = useVideoConfig();
  const local = f - at;
  if (local < 0 || local > fps * 1.3) return null;
  const p = local / fps;
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      {Array.from({ length: count }).map((_, i) => {
        const a = (i / count) * Math.PI * 2 + random(`a${i}`) * 0.5;
        const d = spread * (0.5 + random(`d${i}`)) * easeOut(Math.min(1, p));
        const x = width * cx + Math.cos(a) * d;
        const y = height * cy + Math.sin(a) * d;
        const op = interpolate(p, [0, 0.15, 1], [0, 1, 0]);
        const sz = 7 + random(`s${i}`) * 11;
        return <div key={i} style={{ position: "absolute", left: x, top: y, width: sz, height: sz, borderRadius: "50%", background: color, opacity: op }} />;
      })}
    </AbsoluteFill>
  );
};

/** 글로우 펄스 (요소 뒤 은은한 빛 맥동) — 부모에 position:relative/absolute 필요 */
export const GlowPulse: React.FC<{ color?: string; size?: number }> = ({ color = "#2ED4C6", size = 460 }) => {
  const f = useCurrentFrame();
  const s = 1 + 0.08 * Math.sin(f / 8);
  const op = 0.35 + 0.2 * Math.sin(f / 8);
  return <div style={{ position: "absolute", width: size, height: size, borderRadius: "50%", background: `radial-gradient(circle, ${color}66, transparent 70%)`, transform: `translate(-50%,-50%) scale(${s})`, opacity: op, filter: "blur(24px)", pointerEvents: "none" }} />;
};

/** 클립 와이프 전환 (씬 등장용) */
export const ClipWipe: React.FC<{ children: React.ReactNode; start?: number; dur?: number; dir?: "left" | "right" | "up" }> = ({
  children, start = 0, dur = 16, dir = "left",
}) => {
  const f = useCurrentFrame();
  const p = easeOut(interpolate(f, [start, start + dur], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }));
  const inset = dir === "left" ? `0 ${100 - p * 100}% 0 0` : dir === "right" ? `0 0 0 ${100 - p * 100}%` : `${100 - p * 100}% 0 0 0`;
  return <div style={{ clipPath: `inset(${inset})`, WebkitClipPath: `inset(${inset})` }}>{children}</div>;
};
