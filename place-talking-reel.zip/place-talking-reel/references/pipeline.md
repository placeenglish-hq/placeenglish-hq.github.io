# 파이프라인 상세 (place-talking-reel)

## 0) 템플릿 복사 · 설치 (최초 1회)
```bash
cp -r <skill>/template <작업폴더>/shorts-<주제>   # ASCII 경로(공백/한글 X)
cd <작업폴더>/shorts-<주제> && npm install
```

## 1) 기획
주제·타깃·길이(20~35초)·훅 한 줄 확정. 비면 director(메인 에이전트)가 정한다.

## 2) 대본/자막  (서브에이전트: 카피라이터 — references/subagents.md)
- `narration.json` = `{ "<id>": ["문장1", "문장2", ...] }` (씬 수 = 문장 수)
- `src/shorts.ts` = 씬 배열(bg/eyebrow/title 토큰/sub/chips/cta/sfx). `SHORTS` 레지스트리에 등록.
- `src/Root.tsx`에 `<Composition id="...">` 추가(기존 TalkReel 참고).

## 3) 음성 (연속 트랙) — 둘 중 하나
```bash
# A. 내 녹음: 편 전체를 줄 사이 0.5초 이상 쉬며 읽어 recordings/talk.m4a 로 저장
npm run voice:rec                # → public/audio/<id>.mp3 + src/timings.json (쉬는 구간으로 장면 자동 분할)
# B. 11랩스(.env 에 ELEVEN_API_KEY, ELEVEN_VOICE_ID)
npm run voice:eleven             # → 글자 단위 타이밍으로 장면 경계 계산
```
- **문장별로 쪼개 붙이지 않는다.** timings.json이 장면 전환 프레임을 음성에 맞춰 자동 계산.
- 녹음에서 쉬는 구간이 모자라면 글자 수 비례로 나누고 경고를 띄운다 → 줄 사이를 더 길게 쉬고 다시 녹음.

## 4) 효과음
```bash
npm run sfx            # public/sfx/whoosh|pop|ding.wav (로컬 합성, 무료)
```

## 5) 렌더
```bash
npm run dev            # Remotion Studio 미리보기
npm run render:all     # out/*.mp4
```

## 6) 검수 (서브에이전트: 리뷰어 — references/subagents.md)
```bash
npx remotion still <CompId> out/chk-<n>.png --frame=<F>   # 핵심 프레임 스틸
```
스틸을 **실제로 읽어** references/checklist.md로 판정 → 실패 시 2~5 루프백.

## 파일 역할
- `src/shorts.ts` 대본·씬 정의 · `src/Scene.tsx` 씬 비주얼/모션 · `src/Short.tsx` 연속오디오+크로스페이드+SFX+진행바 · `src/Root.tsx` Composition+타이밍 로더(`src/timings.json`).
- `scripts/voice-recorded.mjs`(녹음 분할) · `scripts/voice-eleven.mjs`(11랩스) · `scripts/generate-sfx.mjs`(WAV 합성).

## 주의
- 첫 씬 start=0 페이드인 가드 있음. 씬 최소 길이 확보. 자막 2줄 이내·안전영역 준수.
