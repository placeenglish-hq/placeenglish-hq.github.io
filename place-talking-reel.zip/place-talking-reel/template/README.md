# 플에이스영어 숏폼 (Remotion)

세로 9:16 숏폼을 코드로 렌더합니다. 샘플 2편이 들어 있어요.
- **TipsShort** — 밝은 톤, 학부모 정보형 (4장면)
- **ConceptShort** — 진한 톤, 개념 정리형 (3장면)

브랜드(빨강·파랑·노랑 3색 밴드, Paperlogy 폰트, 로고)는 이미 들어 있습니다. 내용만 바꿔 쓰세요.

## 준비 (한 번만)
```bash
npm install
```
Node.js 18 이상이 필요합니다.

## 1) 목소리 넣기 — 둘 중 하나

**A. 내 녹음 (권장, 무료)**
1. `narration.json`의 한 편을 처음부터 끝까지 읽으며 녹음합니다. **줄이 바뀔 때 0.5초 이상 쉬세요.**
2. 파일을 `recordings/tips.m4a` 처럼 편 이름(id)으로 저장합니다. (휴대폰 녹음 앱 파일 그대로 OK)
3. `npm run voice:rec`
→ 쉬는 구간을 찾아 장면 경계를 자동으로 잡고 `public/audio/`와 `src/timings.json`을 만듭니다.

**B. 11랩스(내 목소리 클론)**
1. `.env.example`을 `.env`로 복사하고 `ELEVEN_API_KEY`, `ELEVEN_VOICE_ID`를 채웁니다.
2. `npm run voice:eleven`
→ 글자 단위 타이밍으로 장면 경계를 계산합니다.

> 기계음(무료 TTS)은 넣지 않았습니다. 학부모 영상은 원장님 목소리가 신뢰를 만들기 때문이에요.
> `.env`의 키는 절대 공유·업로드하지 마세요.

## 2) 효과음 (선택)
```bash
npm run sfx
```
`public/sfx/whoosh|pop|ding.wav`를 만듭니다. 만든 뒤에는 장면 전환에서 자동으로 재생돼요.

## 3) 미리보기와 렌더
```bash
npm run dev            # 브라우저 미리보기
npm run render:tips    # → out/tips.mp4
npm run render:all
```
렌더 중 컴퓨터가 멈추면 `remotion.config.ts`의 `setConcurrency(2)`를 `1`로 낮추세요.

## 내용 바꾸기
- `src/shorts.ts` — 장면(캡션·강조·칩·CTA). **여기만 고치면 내용이 바뀝니다.** 장면 개수 = `narration.json` 줄 수.
- `narration.json` — 말할 문장. 편 이름(id)은 `shorts.ts`의 `id`와 같아야 합니다.
- 새 편 추가: `shorts.ts`에 `ShortData` 추가 → `Root.tsx`에 `<Composition>` 한 줄 → `package.json`에 render 스크립트.
- 색 변경은 `src/theme.ts`에서만.

## 광고 문구 규칙
"1등", "합격 보장", "100%", 근거 없는 수치, 특정 학생 실명·얼굴(동의 없이)은 넣지 않습니다. 신청 안내는 "프로필 링크의 상담 신청서"로 통일하세요.
