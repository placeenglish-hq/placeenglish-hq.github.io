Paperlogy 7Bold / 8ExtraBold / 9Black (woff2) — 플에이스영어 브랜드 폰트. 로드는 src/fonts.ts.
