import { Config } from "@remotion/cli/config";

Config.setVideoImageFormat("jpeg");
Config.setOverwriteOutput(true);
// 숏폼 세로 렌더 품질
Config.setConcurrency(2);
