import React from "react";
import { AbsoluteFill, Audio, interpolate, Sequence, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { Scene } from "./Scene";
import { Grain } from "./motion";
import { C } from "./theme";
import { ShortData } from "./shorts";

export type Timing = { start: number; dur: number };
export type ShortProps = {
  short: ShortData;
  timings: Timing[];
  audioReady: boolean;
  sfxEnabled: boolean;
  ext?: string; // 오디오 확장자 (녹음/11랩스=mp3 또는 wav)
};

const F = 9; // 크로스페이드 프레임

export const Short: React.FC<ShortProps> = ({ short, timings, audioReady, sfxEnabled, ext = "mp3" }) => {
  const gf = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();

  return (
    <AbsoluteFill style={{ backgroundColor: C.navy3 }}>
      {/* 연속 음성 트랙 (전체 대본 1회 합성) */}
      {audioReady && <Audio src={staticFile(`audio/${short.id}.${ext}`)} />}

      {/* 씬 — 크로스페이드로 겹쳐 전환 */}
      {short.scenes.map((sc, i) => {
        const t = timings[i] ?? { start: i * 120, dur: 120 };
        const end = t.start + t.dur;
        if (gf < t.start - F - 1 || gf > end + 1) return null;
        const opIn = t.start <= 0 ? 1 : interpolate(gf, [Math.max(0, t.start - F), t.start], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
        const opOut = interpolate(gf, [end - F, end], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
        return (
          <Sequence key={i} from={Math.max(0, t.start - F)} durationInFrames={end + 2 - Math.max(0, t.start - F)}>
            <AbsoluteFill style={{ opacity: Math.min(opIn, opOut) }}>
              <Scene data={sc} frame={gf - t.start} dur={t.dur} lead={Math.min(F, t.start)} />
            </AbsoluteFill>
          </Sequence>
        );
      })}

      {/* 효과음 — 씬 전환 순간(어댑티브 액션) */}
      {sfxEnabled && short.scenes.map((sc, i) =>
        sc.sfx ? (
          <Sequence key={`sfx-${i}`} from={timings[i]?.start ?? 0} durationInFrames={30}>
            <Audio src={staticFile(`sfx/${sc.sfx}.wav`)} volume={0.3} />
          </Sequence>
        ) : null
      )}

      {/* 필름 그레인 (질감) */}
      <Grain opacity={0.05} />

      {/* 상단 3색 밴드 (브랜드 시그니처: 빨강·파랑·노랑) */}
      <AbsoluteFill style={{ justifyContent: "flex-start" }}>
        <div style={{ display: "flex", height: 14 }}>
          <div style={{ flex: 1, background: C.red }} /><div style={{ flex: 1, background: C.blue }} /><div style={{ flex: 1, background: C.yellow }} />
        </div>
      </AbsoluteFill>

      {/* 진행바 */}
      <AbsoluteFill style={{ justifyContent: "flex-end" }}>
        <div style={{ height: 8, background: "rgba(255,255,255,.18)" }}>
          <div style={{ height: "100%", width: `${(gf / durationInFrames) * 100}%`, background: C.yellow }} />
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
