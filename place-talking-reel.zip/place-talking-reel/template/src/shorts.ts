import { BgKind, C, FPS } from "./theme";

export type Token = { t: string; hl?: boolean; color?: string };
export type Chip = { t: string; kind: "blue" | "red" };
export type Role = "S" | "V" | "O" | "M"; // 주어 파랑 · 동사 빨강 · 목적어/보어 노랑 · 수식어 회색
export type SynPart = { t: string; r?: Role };
export type CapLine = { at: number; text: string }; // at = 클립 시작 기준 초
export type ClipData = {
  src: string;              // public/clips/ 아래 파일 (예: "clips/hook.mp4")
  mode: "full" | "panel";   // full = 화면 가득 / panel = 아래쪽 패널
  startFrom?: number;       // 클립에서 시작할 초
  audio?: boolean;          // true 면 클립 소리도 (기본 무음 — 내 목소리가 주인공)
  caps?: CapLine[];         // 클립 위 영어/한글 자막
};
export type SceneData = {
  bg: BgKind;
  eyebrow?: string;
  title: Token[];       // 큰 캡션 (강조 토큰 hl)
  sub?: string;
  chips?: Chip[];
  cta?: string;
  defaultDur: number;   // 오디오 없을 때 기본 길이(프레임)
  sfx?: "whoosh" | "pop" | "ding";
  clip?: ClipData;
  syntax?: SynPart[][];   // 문장 색 구분 카드(문장 배열, 문장은 조각 배열)
};
export type ShortData = { id: string; scenes: SceneData[] };

const s = (n: number) => Math.round(n * FPS);

// 샘플 2편 — 내용은 매번 새로 쓴다(구조와 모션만 재사용). 근거 없는 수치·보장 문구 금지.
// bg: "cream"(밝은 배경) | "navy"(진한 배경) | "blue"(브랜드 블루)
// title 토큰: { t, hl:true } = 형광펜/노랑 강조, { t, color } = 지정색

// 샘플 — 영상 클립 없이도 렌더되는 틀입니다. 클립을 쓰려면 public/clips/ 에 mp4를 넣고 clip 을 채우세요.
// (아이 얼굴이 나오는 영상은 학부모 동의를 받은 것만 쓰세요. 동의가 없으면 블러.)
export const TALK: ShortData = {
  id: "talk",
  scenes: [
    { bg: "navy", eyebrow: "초등 문장 → 중등 내신", sfx: "pop", defaultDur: s(4),
      title: [{ t: "초1 문장이\n" }, { t: "중등 문장", color: C.yellow }, { t: "으로\n자라요" }] },
    { bg: "cream", eyebrow: "초등 1~2학년", sfx: "whoosh", defaultDur: s(6),
      title: [{ t: "짧은 문장부터" }],
      syntax: [
        [{ t: "I", r: "S" }, { t: " " }, { t: "like", r: "V" }, { t: " " }, { t: "apples", r: "O" }],
        [{ t: "She", r: "S" }, { t: " " }, { t: "is", r: "V" }, { t: " " }, { t: "happy", r: "O" }],
      ] },
    { bg: "cream", eyebrow: "중등", sfx: "whoosh", defaultDur: s(7),
      title: [{ t: "같은 뼈대로 길어져요" }],
      syntax: [
        [{ t: "The girl in the red coat", r: "S" }, { t: " " }, { t: "likes", r: "V" }, { t: " " }, { t: "the apples on the table", r: "O" }],
      ] },
    { bg: "navy", eyebrow: "설명회 안내", sfx: "ding", defaultDur: s(5),
      title: [{ t: "프로필 링크의\n" }, { t: "상담 신청서", color: C.yellow }],
      cta: "▶ 지금 신청하세요" },
  ],
};

export const SHORTS: Record<string, ShortData> = { TalkReel: TALK };
