export const FPS = 30;
export const W = 1080;
export const H = 1920;

// 플에이스영어 브랜드 토큰 — 색은 여기서만 바꾼다
export const C = {
  red: "#EA5242", blue: "#2A8AD2", yellow: "#FFCC28", orange: "#F2AA24",
  ink: "#181822", ink2: "#3A3A4A", ink3: "#6B6B7B",
  cream: "#FAF7F0", card: "#FFFFFF", line: "#E8E2D4",
  navy: "#1B2959", navy2: "#14204A", navy3: "#0E1736",
  blueWash: "#E4F1FB", yellowHl: "#FFE580", redWash: "#FDE9E6",
} as const;

export type BgKind = "cream" | "navy" | "blue";

export const BG: Record<BgKind, string> = {
  cream: `radial-gradient(70% 45% at 12% 8%, ${C.blueWash}, transparent 60%), ${C.cream}`,
  navy: `radial-gradient(55% 45% at 22% 26%, rgba(42,138,210,.28), transparent 60%), radial-gradient(55% 45% at 80% 78%, rgba(255,204,40,.14), transparent 60%), linear-gradient(135deg,${C.navy},${C.navy2} 55%,${C.navy3})`,
  blue: `radial-gradient(60% 40% at 82% 8%, rgba(255,255,255,.22), transparent 60%), linear-gradient(150deg,${C.blue},${C.navy})`,
};

export const textColor: Record<BgKind, string> = { cream: C.ink, navy: "#FFFFFF", blue: "#FFFFFF" };
export const subColor: Record<BgKind, string> = { cream: C.ink3, navy: "#B9C6E6", blue: "#DCEBFA" };
