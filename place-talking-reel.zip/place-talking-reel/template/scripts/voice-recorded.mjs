// 내 녹음 → 쇼츠 음성 + 장면 타이밍
// 사용: 대본(narration.json)의 한 편을 처음부터 끝까지 읽어서 녹음(줄 사이에 0.5초 이상 쉬기)
//       recordings/<id>.m4a (또는 .wav .mp3 .aac .mp4 .mov) 로 저장 → npm run voice:rec
// 하는 일: 소리 없는 구간을 찾아 줄 수만큼 장면 경계를 자동으로 잡고, public/audio/<id>.mp3 와 src/timings.json 을 만든다.
import { existsSync, mkdirSync, readdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { ffmpeg, probeDuration, loadNarration, saveTiming, ROOT } from "./lib.mjs";

const N = loadNarration();
const recDir = new URL("recordings/", ROOT);
mkdirSync(recDir, { recursive: true });
mkdirSync(new URL("public/audio/", ROOT), { recursive: true });
const EXT = [".m4a", ".wav", ".mp3", ".aac", ".mp4", ".mov", ".ogg"];
const only = process.argv[2]; // 선택: 특정 id 만

for (const [id, lines] of Object.entries(N)) {
  if (only && only !== id) continue;
  const src = readdirSync(recDir).find((f) => f.startsWith(id + ".") && EXT.some((e) => f.toLowerCase().endsWith(e)));
  if (!src) { console.log(`- ${id}: recordings/${id}.m4a 없음 → 건너뜀`); continue; }
  const srcPath = fileURLToPath(new URL(src, recDir));
  const outPath = fileURLToPath(new URL(`public/audio/${id}.mp3`, ROOT));

  // 1) 정리: 모노 48k mp3, 앞뒤 무음 제거 없이 음량만 평준화
  const enc = ffmpeg(["-y", "-i", srcPath, "-vn", "-af", "loudnorm=I=-16:TP=-1.5:LRA=11", "-ar", "48000", "-ac", "1", "-b:a", "160k", outPath]);
  if (enc.status !== 0) { console.error(`✗ ${id}: 변환 실패\n${enc.stderr?.slice(-400)}`); process.exitCode = 1; continue; }
  const total = probeDuration(outPath);

  // 2) 무음 구간 찾기 (여러 임계값을 시도해서 줄 수 - 1 개 이상 확보)
  const need = lines.length - 1;
  let gaps = [];
  for (const [db, d] of [[-35, 0.35], [-32, 0.30], [-30, 0.25], [-28, 0.2], [-25, 0.15]]) {
    const r = ffmpeg(["-i", outPath, "-af", `silencedetect=noise=${db}dB:d=${d}`, "-f", "null", "-"]);
    const txt = r.stderr || "";
    const st = [...txt.matchAll(/silence_start:\s*([\d.]+)/g)].map((m) => +m[1]);
    const en = [...txt.matchAll(/silence_end:\s*([\d.]+)/g)].map((m) => +m[1]);
    gaps = st.map((s, i) => ({ s, e: en[i] ?? total })).filter((g) => g.s > 0.3 && g.e < total - 0.1);
    if (gaps.length >= need) break;
  }

  let cuts, source;
  if (gaps.length >= need) {
    // 가장 긴 need 개를 고르고 시간순으로 정렬 → 각 무음의 중간을 장면 경계로
    const pick = [...gaps].sort((a, b) => (b.e - b.s) - (a.e - a.s)).slice(0, need).sort((a, b) => a.s - b.s);
    cuts = pick.map((g) => +((g.s + g.e) / 2).toFixed(3));
    source = "silence";
  } else {
    const chars = lines.map((l) => l.replace(/[^가-힣A-Za-z0-9]/g, "").length);
    const sum = chars.reduce((a, b) => a + b, 0);
    let acc = 0;
    cuts = chars.slice(0, -1).map((c) => +((acc += c) / sum * total).toFixed(3));
    source = "proportional";
    console.warn(`  ⚠ ${id}: 줄 사이 쉬는 구간이 ${gaps.length}개뿐(필요 ${need}) → 글자 수 비례로 나눔. 줄 사이를 더 길게 쉬고 다시 녹음하면 정확해져요.`);
  }
  cuts.push(+total.toFixed(3));
  saveTiming(id, { total: +total.toFixed(3), cuts, voice: "recording", source, ext: "mp3" });
  console.log(`✓ ${id}: ${total.toFixed(1)}초, 장면 ${lines.length}개 (${source}) cuts=[${cuts.join(", ")}]`);
}
