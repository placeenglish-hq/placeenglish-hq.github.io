// 컴퓨터가 약해도 끝까지 렌더되는 조각 렌더 (200프레임씩 → 이어붙이기, 실패 조각만 재시도)
// 사용: npm run render            (기본 TalkReel → out/talk.mp4)
//       npm run render -- TalkReel out/talk.mp4
import { spawnSync } from "node:child_process";
import { mkdirSync, writeFileSync, readFileSync, existsSync, rmSync } from "node:fs";
import { ffmpeg } from "./lib.mjs";

const [comp = "TalkReel", out = "out/talk.mp4"] = process.argv.slice(2);
const id = comp === "TalkReel" ? "talk" : comp;
const t = JSON.parse(readFileSync("src/timings.json", "utf8"))[id];
const frames = t?.cuts?.length ? Math.round(t.total * 30) : 540;
const CH = 200; mkdirSync("out/chunks", { recursive: true });
const list = [];
for (let s = 0, k = 0; s < frames; s += CH, k++) {
  const e = Math.min(s + CH - 1, frames - 1), f = `out/chunks/c${String(k).padStart(3, "0")}.mp4`;
  list.push(f);
  for (let tr = 0; tr < 3 && !existsSync(f); tr++) {
    console.log(`조각 ${k + 1}/${Math.ceil(frames / CH)} (${s}-${e}) 시도 ${tr + 1}`);
    spawnSync("npx", ["remotion", "render", comp, f, `--frames=${s}-${e}`, "--concurrency=1", "--muted", `--crf=${process.env.CRF || 16}`], { stdio: "inherit", shell: process.platform === "win32" });
  }
  if (!existsSync(f)) { console.error("✗ 조각 렌더 실패 — 컴퓨터 메모리를 확인하세요"); process.exit(1); }
}
writeFileSync("out/chunks/list.txt", list.map((f) => `file '${f.replace("out/chunks/", "")}'`).join("\n"));
const silent = "out/chunks/silent.mp4";
let r = ffmpeg(["-y", "-f", "concat", "-safe", "0", "-i", "out/chunks/list.txt", "-c", "copy", silent]);
if (r.status !== 0) { console.error(r.stderr?.slice(-500)); process.exit(1); }
// 음성 + 효과음 합치기: 조각은 무음(--muted)이라 오디오는 Remotion 으로 한 번 더 뽑아 입힌다
const aud = "out/chunks/audio.aac";
spawnSync("npx", ["remotion", "render", comp, aud, "--codec=aac"], { stdio: "inherit", shell: process.platform === "win32" });
r = ffmpeg(["-y", "-i", silent, "-i", aud, "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k", "-shortest", out]);
if (r.status !== 0) { console.error(r.stderr?.slice(-500)); process.exit(1); }
rmSync("out/chunks", { recursive: true, force: true });
console.log("✓", out, "→ 다음: npm run encode -- " + out + " out/talk_final.mp4");
