// ElevenLabs(11랩스) 음성 → 쇼츠 음성 + 글자 단위 타이밍으로 장면 경계 계산
// 준비: .env 에  ELEVEN_API_KEY=...   ELEVEN_VOICE_ID=...  (내 목소리 클론/라이브러리 음성의 ID)
// 선택: ELEVEN_MODEL (기본 eleven_multilingual_v2)
// 실행: npm run voice:eleven   (특정 편만: npm run voice:eleven -- tips)
import { writeFileSync, mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { loadNarration, saveTiming, ROOT } from "./lib.mjs";

const KEY = process.env.ELEVEN_API_KEY, VOICE = process.env.ELEVEN_VOICE_ID;
const MODEL = process.env.ELEVEN_MODEL || "eleven_multilingual_v2";
if (!KEY || !VOICE) { console.error("✗ .env 에 ELEVEN_API_KEY, ELEVEN_VOICE_ID 를 넣어 주세요 (README 참고)"); process.exit(1); }

const N = loadNarration();
mkdirSync(new URL("public/audio/", ROOT), { recursive: true });
const only = process.argv[2];

for (const [id, lines] of Object.entries(N)) {
  if (only && only !== id) continue;
  const text = lines.join(" ");
  const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${VOICE}/with-timestamps?output_format=mp3_44100_128`, {
    method: "POST",
    headers: { "xi-api-key": KEY, "Content-Type": "application/json" },
    body: JSON.stringify({ text, model_id: MODEL, voice_settings: { stability: 0.5, similarity_boost: 0.8, style: 0.2, speed: 1.0 } }),
  });
  if (!res.ok) { console.error(`✗ ${id}: ${res.status} ${(await res.text()).slice(0, 300)}`); process.exitCode = 1; continue; }
  const j = await res.json();
  writeFileSync(fileURLToPath(new URL(`public/audio/${id}.mp3`, ROOT)), Buffer.from(j.audio_base64, "base64"));

  const a = j.alignment || j.normalized_alignment;
  const st = a.character_start_times_seconds, en = a.character_end_times_seconds;
  // 줄 i 가 시작하는 글자 위치 → 그 글자의 시작 시각이 이전 장면의 끝(=다음 장면의 시작)
  let pos = 0; const cuts = [];
  lines.forEach((l, i) => {
    pos += l.length + 1; // 공백 1칸
    if (i < lines.length - 1) cuts.push(+Math.max(0, st[Math.min(pos, st.length - 1)] - 0.12).toFixed(3));
  });
  const total = +(en[en.length - 1] + 0.4).toFixed(3);
  cuts.push(total);
  saveTiming(id, { total, cuts, voice: "elevenlabs:" + VOICE, source: "alignment", ext: "mp3" });
  console.log(`✓ ${id}: ${total}초 cuts=[${cuts.join(", ")}]`);
}
