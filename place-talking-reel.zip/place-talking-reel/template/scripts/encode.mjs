// 카카오톡·인스타 호환 인코딩 — 사용: npm run encode -- out/talk.mp4 out/talk_final.mp4
import { ffmpeg } from "./lib.mjs";
const [inp = "out/talk.mp4", out = "out/talk_final.mp4"] = process.argv.slice(2);
const r = ffmpeg(["-y", "-i", inp, "-c:v", "libx264", "-crf", "20", "-pix_fmt", "yuv420p", "-r", "30", "-vsync", "cfr", "-profile:v", "high", "-level", "4.0",
  "-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-ac", "2", "-movflags", "+faststart", out]);
if (r.status !== 0) { console.error(r.stderr?.slice(-600)); process.exit(1); }
console.log("✓", out);
