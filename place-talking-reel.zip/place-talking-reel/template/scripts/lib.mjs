// 공용 유틸 — ffmpeg 실행 / timings.json 병합
import { spawnSync } from "node:child_process";
import { readFileSync, writeFileSync, existsSync } from "node:fs";

export const ROOT = new URL("../", import.meta.url);

// ffmpeg: 시스템 ffmpeg 우선, 없으면 remotion 내장 (npx remotion ffmpeg)
export const ffmpeg = (args, opts = {}) => {
  let r = spawnSync("ffmpeg", args, { encoding: "utf8", maxBuffer: 1 << 28, ...opts });
  if (r.error) r = spawnSync("npx", ["remotion", "ffmpeg", ...args], { encoding: "utf8", maxBuffer: 1 << 28, shell: process.platform === "win32", ...opts });
  return r;
};

export const probeDuration = (file) => {
  const r = ffmpeg(["-i", file]);
  const m = /Duration:\s*(\d+):(\d+):([\d.]+)/.exec((r.stderr || "") + (r.stdout || ""));
  if (!m) throw new Error("길이를 읽지 못했어요: " + file);
  return +m[1] * 3600 + +m[2] * 60 + +m[3];
};

export const loadNarration = () => JSON.parse(readFileSync(new URL("narration.json", ROOT), "utf8"));

export const saveTiming = (id, info) => {
  const f = new URL("src/timings.json", ROOT);
  const all = existsSync(f) ? JSON.parse(readFileSync(f, "utf8")) : {};
  all[id] = info;
  writeFileSync(f, JSON.stringify(all, null, 2));
};
