---
name: place-talking-reel
description: 플에이스영어 "말하는 릴스" — 원장님 목소리(녹음/11랩스)에 영상 클립·문장 색 카드(주어 파랑·동사 빨강·목적어 노랑)·자막·CTA를 얹은 9:16 인스타 릴스를 만든다. "말하는 릴스", "목소리 릴스", "신텍스 릴스", "릴스 만들어줘" 요청에 사용한다.
---

# 말하는 릴스 (place-talking-reel)

원장님이 말하는 목소리 위에 **영상 클립 + 문장 색 카드 + 자막 + 설명회 CTA**를 얹는 1분 안팎의 릴스. 템플릿은 place-shorts에 *영상 클립 장면*과 *문장 색 카드*를 더한 것이다.

## 장면 종류 (`src/shorts.ts`)
- **글자 장면**: `title`(큰 제목, `hl`/`color` 강조), `sub`, `chips`, `cta`
- **클립 장면**: `clip: { src, mode: "full" | "panel", startFrom, caps }`
  - `full` = 화면 가득(훅용), `panel` = 아래쪽 패널(위에 설명이 보이게)
  - `caps` = 클립 위 자막 `[{ at: 초, text }]` (영어 문장 등)
  - 클립은 기본 무음(내 목소리가 주인공). 소리가 필요하면 `audio: true`
- **문장 색 카드**: `syntax: [[{t, r:"S"|"V"|"O"|"M"}, ...], ...]` — 주어 파랑, 동사 빨강, 목적어·보어 노랑(+【 】), 수식어 회색. 아래 `legend`가 자동으로 붙는다.

## 파이프라인
1. **기획** — 한 가지 메시지(예: "초1 문장이 중등 문장으로 자란다"), 길이 40~60초, 첫 3초 훅.
2. **복사·설치** — `cp -r template <작업폴더>/reel-<주제>` → `npm install` (Node 18+)
3. **클립 준비** — 영상은 `public/clips/`에 넣는다. 세로 영상이 아니어도 `cover`로 채워진다. 아이 얼굴은 **동의받은 것만**, 아니면 블러.
4. **대본·장면** — `narration.json`(말할 줄)과 `src/shorts.ts`(장면). 장면 수 = 줄 수. 색 규칙은 `references/syntex-colors.md`.
5. **음성** — (A) 줄 사이 0.5초 이상 쉬며 한 번에 녹음 → `recordings/talk.m4a` → `npm run voice:rec` / (B) 11랩스 `.env` → `npm run voice:eleven`
6. **효과음** — `npm run sfx`
7. **미리보기** — `npm run dev`
8. **렌더** — `npm run render` (조각 렌더라 느린 컴퓨터도 끝까지 간다) → `out/talk.mp4`
9. **카톡·인스타용 인코딩** — `npm run encode -- out/talk.mp4 out/talk_final.mp4`
10. **검수** — `npx remotion still TalkReel out/chk-N.png --frame=F`로 장면마다 확인 → `references/checklist.md`
11. **본문·썸네일** — `references/caption-and-thumbnail.md`

## 반드시 지킬 것
- 색·폰트·로고 변경 금지(`src/theme.ts`, `src/fonts.ts`).
- "1등", "합격 보장", "100%", "선행" 같은 표현, 근거 없는 수치, 가짜 후기 금지.
- 신청 안내는 "프로필 링크의 상담 신청서". 설명회 날짜는 매번 사용자에게 확인한다.
- 음악·영상·아이 얼굴은 권리/동의가 확인된 것만. 확인 안 되면 사용하지 않는다.

## 화질을 높여 달라고 할 때
원장님이 "화질을 더 선명하게"라고 하면 렌더할 때 화질 값(`--crf`)을 낮춰서 다시 렌더합니다. 기본은 16~18이고, 12~14로 낮추면 더 선명하지만 파일이 커집니다. 원본 영상 자체가 흐리면 렌더만으로는 선명해지지 않으니, 원본이 흐린지 먼저 확인해서 알려 줍니다. 인스타그램에 올릴 때 한 번 더 압축되는 것은 막을 수 없다고 안내합니다.
